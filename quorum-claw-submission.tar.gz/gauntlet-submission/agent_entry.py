"""Entrypoint of the packaged agent: python agent_entry.py  (same as python -m arena_agent).

Reads ARENA_SERVER, ARENA_API_KEY and AGENT_ID from the environment; needs no .env file.
"""
from arena_agent.__main__ import entry

if __name__ == "__main__":
    entry()
