"""Image challenges: fetch the challenge, let the arena's own image tool make the picture, submit it.

Fixed steps like the text flow (no model decides them):
1. arena.image.get_challenge: the prompt (or edit_prompt), description, reference notes, the input image and
   the time limit.
2. A thought through the image channel (arena.image.broadcast_thought) and through the web API.
3. The arena's image tool does the work: the edit tool on the input image, else the generate tool. When the
   tool advertises a "model" field, the best image model on the roster for the job is named (the job's makers
   in MAKER_PREFERENCE, then aliases ending in -image, then models listing the image capability); an empty or
   failed result is tried once more with the next one, while time allows. A new picture whose request rules out
   text gets NO_TEXT_LINE.
4. arena.image.submit_edit with the picture; the web API is the fallback. Without a new picture the input
   image goes in unchanged, never an empty one.
"""
from __future__ import annotations

import asyncio
import base64
import re
import struct
import time
import zlib
from typing import Any, Awaitable, Callable

from arena_agent.background import leave_quietly
from arena_agent.mcp_link import McpLink
from arena_agent.rest import Rest

GET_CHALLENGE = "arena.image.get_challenge"
BROADCAST = "arena.image.broadcast_thought"
SUBMIT = "arena.image.submit_edit"
IMAGE_TRIES = 2          # the output tool, then once more with the next image model
SUBMIT_MARGIN_S = 3.0    # kept free for the submission itself
VERIFY_MIN_LEFT_S = 25.0  # the check of an edit and one more edit need this much time left; otherwise no check
VERIFY_MAX_S = 10.0       # the analyze call gets at most this long
_NO = re.compile(r"^\W*no\b", re.I)   # a verdict that starts with No

#: Image makers by job, measured on the organizer's Practice (29 October, the same two puzzles each time): for a new
#: picture Lite scored as well as Pro (image score 85.8 in 5 rounds, Pro 87.3 in 3) in a quarter of the time and
#: Flash worse (77.8 in 4); for an edit Flash and Pro kept the rest of the picture better than Lite (84.0 in 2 and
#: 85.0 in 3, Lite 78.6 in 7), and Flash is the faster of the two. Makers not named follow in roster order.
MAKER_PREFERENCE: dict[str, tuple[str, ...]] = {
    "generate": ("gemini-3.1-flash-lite-image",),
    "edit": ("gemini-3.1-flash-image", "gemini-3-pro-image"),
}
#: Image makers fill a street with readable signs, and the judge counts them against a "no text" rule (Practice,
#: 29 October: rules part 61 on average without this line, 76 with it, in 5 and 4 rounds, no time lost). Only for a
#: new picture: an edit keeps the input picture's own signs.
NO_TEXT_LINE = ("\n\nNo readable text anywhere in the picture: signs, screens, billboards and labels stay blank or "
                "blurred, with no letters, words or numbers.")
_FORBIDS_TEXT = re.compile(r"\bno (?:visible |readable |legible )?(?:text|lettering|letters|words|writing|captions?)\b"
                           r"|\bwithout (?:any )?(?:visible |readable )?(?:text|lettering|letters|words|writing)\b"
                           r"|\bavoid\b[^.\n]{0,40}\b(?:text|lettering|letters|words|writing)\b|\btext-free\b", re.I)


def _blank_png() -> str:
    """A 1x1 white PNG as a data URI, built here so it is valid by construction."""
    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(b"\x00\xff\xff\xff")) + chunk(b"IEND", b""))
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii")


#: Only when there is neither a new picture nor an input image to hand back.
BLANK_PNG = _blank_png()


def image_models(rows: list[dict[str, Any]], job: str = "") -> list[str]:
    """Image-capable aliases on the roster: the job's makers in MAKER_PREFERENCE first, then names ending in -image
    (made for generating and editing), then models that list the image capability."""
    ids = [str(r.get("id")) for r in rows if isinstance(r, dict) and r.get("id")]
    makers = [m for m in ids if m.lower().endswith("-image")]
    capable = [str(r["id"]) for r in rows if isinstance(r, dict) and r.get("id")
               and "image" in (r.get("capabilities") or []) and str(r["id"]) not in makers]
    found = makers + capable
    first = [m for m in MAKER_PREFERENCE.get(job, ()) if m in found]
    return first + [m for m in found if m not in first]


def forbids_text(request: str) -> bool:
    """Whether an image request rules out text in the picture ("no text", "without lettering", "avoid ... text")."""
    return bool(_FORBIDS_TEXT.search(request))


def find_tool(tools: dict[str, set[str]], job: str) -> str | None:
    """The arena's image tool for one job ('edit', 'generate', 'analyze'), whatever its name space."""
    for name in sorted(tools):
        low = name.lower()
        if "image" in low and job in low and not any(s in low for s in ("submit", "get_challenge", "broadcast")):
            return name
    return None


def is_image(uri: str) -> bool:
    return uri.startswith("data:image/") or uri.startswith("https://") or uri.startswith("http://")


async def run_image(cfg: Any, rest: Rest, mcp: McpLink, tools: dict[str, set[str]], rows: list[dict[str, Any]],
                    challenge: dict[str, Any], deadline_of: Callable[[float, float], float],
                    log: Callable[[str], None], result: dict[str, Any],
                    before_submit: Callable[[], Awaitable[Any]] | None = None) -> None:
    """Steps 2 to 4 for a fetched image challenge; fills ``result`` and always submits something.
    ``before_submit`` runs just before the submission (the agent calls the challenge's required tools there)."""
    t0 = time.monotonic()
    prompt =str(challenge.get("prompt") or challenge.get("edit_prompt") or challenge.get("description") or "")
    notes = str(challenge.get("reference_notes") or "").strip()
    if notes:
        prompt = f"{prompt}\n\nReference notes: {notes}"
    input_uri = str(challenge.get("input_image_uri") or "")
    max_time = float(challenge.get("max_time_s") or 60.0)
    remaining = challenge.get("time_remaining_s")   # 0 means no time left, not "unknown"
    time_left = float(remaining) if isinstance(remaining, (int, float)) else max_time
    submit_by = deadline_of(time_left, max_time)
    result.update(challenge_type=str(challenge.get("challenge_type") or "image"),
                  puzzle_id=challenge.get("puzzle_id") or challenge.get("challenge_id"))

    edit_tool = find_tool(tools, "edit") if input_uri else None
    tool = edit_tool or find_tool(tools, "generate")
    models = image_models(rows, "edit" if edit_tool else "generate")
    maker_prompt = prompt
    if tool and not edit_tool and forbids_text(prompt):
        maker_prompt = prompt + NO_TEXT_LINE
        result["no_text_line"] = True
    plan = f"image challenge: {tool or 'no image tool'} with {models[0] if models else 'the arena default model'}"
    note = "; no-text line added" if maker_prompt != prompt else ""
    log(f"{plan}; {time_left:.0f} s of {max_time:.0f} s left{note}")
    if BROADCAST in tools:
        try:
            await mcp.call(BROADCAST, {"thought": plan, "agent_id": cfg.agent_id})
        except Exception as exc:  # noqa: BLE001 - the web API thought below still counts
            log(f"image thought failed: {exc}")
    try:
        await asyncio.to_thread(rest.thought, cfg.agent_id, plan)
    except Exception as exc:  # noqa: BLE001
        log(f"thought failed: {exc}")

    output, used_model, tries = "", None, []
    for model in (models or [""])[:IMAGE_TRIES]:
        left = submit_by - time.monotonic() - SUBMIT_MARGIN_S
        if not tool or left <= 1.0:
            break
        args: dict[str, Any] = {"prompt": maker_prompt, "agent_id": cfg.agent_id}
        if tool == edit_tool:
            args["image_uri"] = input_uri
        if model and "model" in tools.get(tool, set()):
            args["model"] = model
        call = asyncio.ensure_future(mcp.call(tool, args))
        done, _ = await asyncio.wait({call}, timeout=left)
        if not done:   # left running: an image after the submit time is of no use
            leave_quietly([call])
            tries.append({"tool": tool, "model": model, "outcome": "no image before submit"})
            log(f"{tool} with {model or 'the default model'} took too long")
            break
        try:
            data = call.result()
        except Exception as exc:  # noqa: BLE001 - try the next model
            tries.append({"tool": tool, "model": model, "outcome": "failed", "error": str(exc)[:200]})
            log(f"{tool} failed: {exc}")
            continue
        uri = str(data.get("image_uri") or "").strip()
        if is_image(uri):
            output, used_model = uri, model or None
            tries.append({"tool": tool, "model": model, "outcome": "image"})
            break
        tries.append({"tool": tool, "model": model, "outcome": "no image", "error": str(data.get("error"))[:200]})
        log(f"{tool} gave no image ({data.get('error')})")

    # The first submission is final, so the edit is looked at before it goes in: the analyze tool says
    # whether the instruction shows in the image; a clear No gets one more edit with a sharper prompt.
    checked = ""
    verify = find_tool(tools, "analyze") if output and tool else None
    if verify and submit_by - time.monotonic() - SUBMIT_MARGIN_S >= VERIFY_MIN_LEFT_S:
        question = (f"Does this image show the result of this instruction: {prompt[:500]!r}? Answer YES or NO first, "
                    "then one sentence on what you see.")
        try:
            reply = await asyncio.wait_for(mcp.call(verify, {"image_uri": output, "question": question,
                                                             "agent_id": cfg.agent_id}), VERIFY_MAX_S)
            # An error is no verdict: on Practice the tool's default reader is not on the roster (HTTP 400), and
            # reading that as an answer made the note say "(checked)" for a picture nobody had looked at.
            problem = str(reply.get("error") or "")
            verdict = "" if problem else str(reply.get("text") or "").strip()
        except Exception as exc:  # noqa: BLE001 - the check is optional; the image stands
            problem, verdict = str(exc) or type(exc).__name__, ""
        result["verify"] = {"tool": verify, "verdict": verdict[:200], "retried": False}
        if problem:
            result["verify"]["error"] = problem[:200]
            log(f"{verify} failed: {problem[:80]}; the image goes in unchecked")
        if _NO.match(verdict):
            log(f"{verify} says the edit is not there ({verdict[:60]}); one more edit")
            again: dict[str, Any] = {"prompt": maker_prompt + "\n\nThe previous attempt did not apply this change. "
                                     "Apply it clearly and keep everything else as it is.", "agent_id": cfg.agent_id}
            if tool == edit_tool:
                again["image_uri"] = input_uri
            if used_model and "model" in tools.get(tool, set()):
                again["model"] = used_model
            call = asyncio.ensure_future(mcp.call(tool, again))
            done, _ = await asyncio.wait({call}, timeout=max(1.0, submit_by - time.monotonic() - SUBMIT_MARGIN_S))
            if not done:
                leave_quietly([call])
                tries.append({"tool": tool, "model": used_model, "outcome": "no image before submit", "retry": True})
                log(f"{tool} took too long the second time; the first image stands")
            else:
                try:
                    uri = str(call.result().get("image_uri") or "").strip()
                except Exception as exc:  # noqa: BLE001
                    uri = ""
                    log(f"{tool} failed the second time: {str(exc)[:80]}")
                if is_image(uri):
                    output, checked = uri, " (second edit after the check)"
                    result["verify"]["retried"] = True
                    tries.append({"tool": tool, "model": used_model, "outcome": "image", "retry": True})
                else:
                    tries.append({"tool": tool, "model": used_model, "outcome": "no image", "retry": True})
        elif verdict:
            checked = " (checked)"
            log(f"{verify}: {verdict[:60]}; the image stands")
    final = output or input_uri or BLANK_PNG
    metrics = {"model_name": used_model or "none", "planner_tool": tool or "none",
               "total_time_ms": round((time.monotonic() - t0) * 1000)}
    rationale = (f"{tool} with {used_model or 'the default model'}{checked}" if output
                 else "no new image; input returned")
    if before_submit is not None:
        try:
            await before_submit()
        except Exception as exc:  # noqa: BLE001 - the image still goes in
            log(f"required tools check failed: {exc}")
    receipt: dict[str, Any] | None = None
    if SUBMIT in tools:
        try:
            receipt = await mcp.call(SUBMIT, {"edited_image": final, "client_metrics": metrics,
                                              "rationale": rationale, "agent_id": cfg.agent_id})
            if receipt.get("error"):
                log(f"{SUBMIT} refused: {receipt.get('error')}")
                receipt = None
        except Exception as exc:  # noqa: BLE001 - the web API is the fallback
            log(f"{SUBMIT} failed: {exc}")
    if receipt is None:
        receipt = await asyncio.to_thread(rest.submit, cfg.agent_id, final, metrics, "image")
    log(f"image submitted ({rationale}); score {receipt.get('score')}")
    if len(str(receipt.get("answer") or "")) > 80:   # the receipt may echo the whole image back
        receipt = {**receipt, "answer": str(receipt["answer"])[:60] + "..."}
    result.update(status="submitted", model=used_model, edited=bool(output), tool=tool, tries=tries,
                  answer=final[:60] + ("..." if len(final) > 60 else ""), receipt=receipt)
