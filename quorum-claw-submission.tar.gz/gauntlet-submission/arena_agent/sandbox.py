"""Run a model-written Python program and return what it prints.

A guard, not a full sandbox: the program is checked before it runs, then runs in a separate Python
process in an empty temporary folder, with no environment variables (so no keys), no stdin, a time
limit, a memory limit (Linux), an import guard inside the child, and no network when the host lets an
unprivileged process open a network namespace (Linux ``unshare``).

The check parses the program and refuses it when it imports anything outside a list of pure
computation modules, aliases ``sys`` or reaches a module through another module (typing.sys), calls a
builtin that reaches files, code or other modules (open, exec, eval, __import__, getattr ...), touches
any attribute that starts with an underscore (``random._os`` is the operating system), uses a dunder
name or string other than the ``__name__ == "__main__"`` idiom, uses ``operator.attrgetter`` or
``methodcaller`` (attribute access by string), uses ``sys`` for more than the recursion limit, maxsize
and stdout, or computes nothing (only prints fixed text). Its output is refused when it is empty or
shows Python's None among numbers (values left unset).

A security review (2026-10-11) found three ways through the earlier check: a private attribute holding
a module, an alias of ``sys``, and a dunder reached through a string. All three are refused now and
tested; the 251 programs logged in practice were re-checked against the new rules.

A second review (2026-10-29) got through again: a module given a second name (``x = typing``) or put in a
list (``[typing][0]``) reached ``sys.modules`` and so ``os``, and a ``match`` pattern reached private
attributes. The check now refuses the dangerous names on any expression and in patterns, and the child
has a second layer that does not depend on the check: once the program starts, Python's audit hooks
refuse files outside the standard library, other programs, the network, raw code objects and tracing.
"""
from __future__ import annotations

import ast
import importlib
import os
import re
import subprocess
import sys
import tempfile
import types
from pathlib import Path

ALLOWED_IMPORTS = frozenset({
    "bisect", "calendar", "collections", "copy", "dataclasses", "datetime", "decimal", "enum", "fractions",
    "functools", "heapq", "itertools", "json", "math", "operator", "random", "re", "statistics", "string",
    "sys", "typing",
})
BLOCKED_NAMES = frozenset({
    "open", "exec", "eval", "compile", "__import__", "input", "breakpoint", "globals", "locals", "vars",
    "getattr", "setattr", "delattr", "memoryview", "help", "exit", "quit", "attrgetter", "methodcaller",
})
BLOCKED_ATTRS = frozenset({"attrgetter", "methodcaller"})
SYS_ALLOWED = frozenset({"setrecursionlimit", "maxsize", "stdout"})
DUNDER_OK = frozenset({"__name__", "__main__"})   # the one idiom programs use: if __name__ == "__main__":
RECURSION_LIMIT = 10_000   # set by the launcher for every program (deep searches), so sys is rarely needed
#: Modules the child may never import at run time, whatever the program's text managed to reach: the
#: network, other processes, files and the system. A second line behind the parse-time check.
DENIED_AT_RUNTIME = (
    "socket", "subprocess", "ctypes", "pickle", "shutil", "urllib", "http", "ftplib", "smtplib", "xmlrpc",
    "multiprocessing", "signal", "pty", "fcntl", "mmap", "select", "selectors", "asyncio", "ssl", "code",
    "codeop", "pdb", "webbrowser", "glob", "pathlib", "tempfile", "sqlite3", "zipfile", "tarfile", "shelve",
    "dbm", "platform", "getpass", "pwd", "grp", "sysconfig", "site", "socketserver", "email", "imaplib",
    "poplib", "telnetlib", "concurrent", "threading", "sched", "wsgiref", "mailbox", "ipaddress",
)
#: A program without any of these (and without a call other than print) only prints fixed text: the model
#: worked the answer out itself (seen in the trial on futoshiki), so it is no program answer at all.
COMPUTING = (ast.For, ast.While, ast.FunctionDef, ast.Lambda, ast.ListComp, ast.SetComp, ast.DictComp,
             ast.GeneratorExp, ast.BinOp, ast.BoolOp, ast.Compare)
MAX_OUTPUT = 4000                    # characters of output kept; an answer is far shorter
#: Printed with exit code 0 and still no answer: an empty container, a bare None or False, "no solution".
#: Such a program gets the repair round like one that crashed (seen in code-assisted ensembles as a cheap gain).
DEGENERATE = frozenset({"[]", "{}", "()", "set()", "none", "false", "no solution", "no solutions", "not found",
                        "no answer", "0 solutions", "null", "nan"})
MEMORY_LIMIT = 1024 * 1024 * 1024   # 1 GB address space on Linux; puzzle searches need far less

_THINK = re.compile(r"<think>.*?</think>", re.S | re.I)
_BLOCK = re.compile(r"```(?:python|py)?[ \t]*\n(.*?)```", re.S | re.I)
_UNSET = re.compile(r"(?<![A-Za-z_])None(?![A-Za-z_])")
_UNDERSCORE_WORD = re.compile(r"^_+[A-Za-z]")


def _module_attrs() -> dict[str, frozenset[str]]:
    """For each allowed module, the names of its public attributes that are modules themselves (typing.sys,
    json.decoder ...): a module reached that way skips the import rules, so such access is refused."""
    out = {}
    for name in ALLOWED_IMPORTS:
        try:
            module = importlib.import_module(name)
        except ImportError:
            continue
        out[name] = frozenset(attr for attr, value in vars(module).items()
                              if isinstance(value, types.ModuleType) and not attr.startswith("_"))
    return out


MODULE_ATTRS = _module_attrs()

#: Modules a program must never reach, under any name: files, other programs, the network, imports, raw code
#: objects, the object graph and the interpreter itself.
DANGEROUS_MODULES = frozenset({
    "sys", "builtins", "os", "posix", "nt", "io", "codecs", "importlib", "types", "inspect", "linecache",
    "tokenize", "gc", "ctypes", "pathlib", "shutil", "subprocess", "socket", "runpy", "marshal", "pickle",
    "threading", "signal", "tempfile",
})


def _danger_names() -> frozenset[str]:
    """Attribute names a program may not use on any value: the dangerous modules' own names, sys.modules, and
    every name under which a module reachable from the allowed ones holds a dangerous module (typing.sys,
    enum.bltns, dataclasses.inspect ...). Checked on any expression, so a second name for a module (x = typing)
    or a module inside a list ([typing][0]) leads nowhere either."""
    names, seen, todo = set(DANGEROUS_MODULES) | {"modules"}, set(), []
    for name in ALLOWED_IMPORTS:
        try:
            todo.append(importlib.import_module(name))
        except ImportError:
            continue
    while todo:
        module = todo.pop()
        if module.__name__ in seen or module.__name__.split(".")[0] in DANGEROUS_MODULES:
            continue
        seen.add(module.__name__)
        for attr, value in vars(module).items():
            if attr.startswith("_") or not isinstance(value, types.ModuleType):
                continue
            if value.__name__.split(".")[0] in DANGEROUS_MODULES:
                names.add(attr)
            else:
                todo.append(value)
    return frozenset(names)


DANGER_NAMES = _danger_names()
#: Run-time events the child refuses once the program starts (Python's audit hooks): other programs, the
#: network, raw code objects, tracing and the object graph. Files are refused unless they are read from the
#: standard library (a module loaded late, such as datetime's _strptime). The second layer behind the check,
#: for whatever the check misses; on its own it would not be a sandbox, as Python's documentation says.
BLOCKED_EVENTS = frozenset({"code.__new__", "function.__new__", "sys.settrace", "sys.setprofile", "builtins.input",
                            "builtins.breakpoint"})
BLOCKED_PREFIXES = ("os.", "subprocess.", "_posixsubprocess.", "socket.", "ctypes.", "shutil.", "glob.", "tempfile.",
                    "mmap.", "sqlite3.", "urllib.", "http.", "ftplib.", "smtplib.", "poplib.", "imaplib.", "nntplib.",
                    "telnetlib.", "webbrowser.", "winreg.", "msvcrt.", "_winapi.", "resource.", "fcntl.", "signal.",
                    "syslog.", "pty.", "gc.", "sys.monitoring")


class CodeError(Exception):
    pass


_RUNNING: set[subprocess.Popen[str]] = set()


def stop_all() -> None:
    """Kill programs still running, so none outlives the agent (it exits right after submitting)."""
    for proc in list(_RUNNING):
        proc.kill()


def extract_code(reply: str) -> str:
    """The last fenced code block of a model reply (models often show a draft first), or ''."""
    blocks = _BLOCK.findall(_THINK.sub("", reply or ""))
    return blocks[-1].strip() if blocks else ""


def check(code: str) -> str | None:
    """None when the program may run, else the reason it may not."""
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return f"syntax error: {exc.msg} (line {exc.lineno})"
    aliases: dict[str, str] = {}   # name bound by an import -> module
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root not in ALLOWED_IMPORTS:
                    return f"import {alias.name} is not allowed"
                if root == "sys" and (alias.asname or "." in alias.name):
                    return "sys may only be imported as sys"
                aliases[alias.asname or root] = root
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if node.level or root not in ALLOWED_IMPORTS or "." in (node.module or ""):
                return f"from {node.module} import is not allowed"
            if root == "sys" and any(alias.name not in SYS_ALLOWED for alias in node.names):
                return "only sys.setrecursionlimit, sys.maxsize and sys.stdout are allowed"
            for alias in node.names:
                if alias.name == "*" or alias.name in MODULE_ATTRS.get(root, ()):
                    return f"from {root} import {alias.name} reaches another module"
                if alias.name in BLOCKED_ATTRS or alias.name.startswith("_"):
                    return f"from {root} import {alias.name} is not allowed"
        elif isinstance(node, ast.Name):
            if node.id in BLOCKED_NAMES:
                return f"{node.id} is not allowed"
            if node.id.startswith("__") and node.id not in DUNDER_OK:
                return f"dunder name {node.id} is not allowed"
        elif isinstance(node, ast.MatchClass):   # case object(attr=x) reads attributes by name, like x.attr
            for attr in node.kwd_attrs:
                if attr.startswith("_") or attr in BLOCKED_ATTRS or attr in DANGER_NAMES:
                    return f"pattern attribute {attr} is not allowed"
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("_"):
                return f"attribute {node.attr} is not allowed (underscore)"
            if node.attr in BLOCKED_ATTRS:
                return f"{node.attr} is not allowed"
            if node.attr in DANGER_NAMES:
                return f"attribute {node.attr} is not allowed (it reaches outside)"
            if isinstance(node.value, ast.Name):
                module = aliases.get(node.value.id)
                if module == "sys" and node.attr not in SYS_ALLOWED:
                    return f"sys.{node.attr} is not allowed"
                if module is not None and node.attr in MODULE_ATTRS.get(module, ()):
                    return f"{node.value.id}.{node.attr} reaches another module"
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value not in DUNDER_OK and ("__" in node.value or _UNDERSCORE_WORD.match(node.value)):
                return "a string naming an underscore attribute is not allowed"
    if not any(isinstance(node, COMPUTING) or _calls_something(node) for node in ast.walk(tree)):
        return "the program computes nothing, it only prints fixed text"
    return None


def _calls_something(node: ast.AST) -> bool:
    return isinstance(node, ast.Call) and not (isinstance(node.func, ast.Name) and node.func.id == "print")


#: The child: the memory limit (Linux), the recursion limit, the allowed modules loaded up front, an import
#: guard that refuses the denied modules whatever the program reached, the program read and compiled, then
#: the audit hook (from here on: no files outside the standard library, no other programs, no network, no
#: raw code objects, no tracing), then the program. preexec_fn is not safe with threads, so the child sets
#: its own limits. A refused event raises PermissionError, an OSError, so a traceback still prints (without
#: source lines) and the repair round sees the real error.
_LAUNCH = (
    "{memory}"
    "import builtins, os, sys\n"
    "sys.setrecursionlimit({limit})\n"
    "for _name in {allowed!r}:\n"
    "    __import__(_name)\n"
    "_denied = {denied!r}\n"
    "_real_import = builtins.__import__\n"
    "def _guarded(name, *args, **kwargs):\n"
    "    if name.split('.')[0] in _denied:\n"
    "        raise ImportError('import ' + name + ' is not allowed here')\n"
    "    return _real_import(name, *args, **kwargs)\n"
    "builtins.__import__ = _guarded\n"
    "with open('solve.py', encoding='utf-8') as _fh:\n"
    "    _program = compile(_fh.read(), 'solve.py', 'exec')\n"
    "_library = tuple(os.path.normcase(os.path.abspath(p)) + os.sep\n"
    "                 for p in (os.path.dirname(os.__file__), os.path.join(sys.base_prefix, 'DLLs')))\n"
    "_own = os.path.normcase(os.path.abspath('solve.py'))\n"   # read back for the source lines of a traceback
    "_blocked, _prefixes = {events!r}, {prefixes!r}\n"
    "def _readable(path):\n"
    "    full = os.path.normcase(os.path.abspath(path))\n"
    "    return full == _own or full.startswith(_library)\n"
    "def _audit(event, args):\n"
    "    if event == 'open':\n"
    "        path, mode = args[0], args[1]\n"
    "        if isinstance(path, str) and isinstance(mode, str) and not set(mode) & set('wax+') and _readable(path):\n"
    "            return\n"
    "        raise PermissionError('opening ' + str(path) + ' is not allowed here')\n"
    "    if event in _blocked or event.startswith(_prefixes):\n"
    "        raise PermissionError(event + ' is not allowed here')\n"
    "_main = type(sys)('__main__')\n"   # the program's own __main__ module, as runpy gave it before
    "sys.modules['__main__'] = _main\n"
    "sys.addaudithook(_audit)\n"
    "exec(_program, _main.__dict__)\n"
)
_MEMORY = "import resource; resource.setrlimit(resource.RLIMIT_AS, ({0}, {0}))\n".format(MEMORY_LIMIT)
#: Linux: a new user and network namespace for the child when an unprivileged process may open one (most
#: desktop and server kernels allow it): the program then has no network at all. Probed once per process.
_UNSHARE = ["unshare", "--user", "--map-root-user", "--net"]
_isolation: list[str] | None = None


def isolation_prefix() -> list[str]:
    """The command prefix that cuts the child's network, or [] when the host cannot do it."""
    global _isolation
    if _isolation is None:
        _isolation = []
        if os.name == "posix":
            try:
                probe = subprocess.run(_UNSHARE + ["true"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, timeout=5.0)
                if probe.returncode == 0:
                    _isolation = list(_UNSHARE)
            except (OSError, subprocess.SubprocessError):
                pass
    return _isolation


def launcher() -> str:
    """The -c program that runs solve.py with this platform's limits."""
    return _LAUNCH.format(memory=_MEMORY if os.name == "posix" else "", limit=RECURSION_LIMIT,
                          allowed=tuple(sorted(ALLOWED_IMPORTS)), denied=DENIED_AT_RUNTIME,
                          events=tuple(sorted(BLOCKED_EVENTS)), prefixes=BLOCKED_PREFIXES)


def run_code(code: str, timeout_s: float) -> str:
    """Check and run the program; return its printed output, stripped. Raises CodeError otherwise."""
    reason = check(code)
    if reason:
        raise CodeError(f"refused: {reason}")
    # No environment at all, so no keys reach the program; Windows needs SYSTEMROOT to start Python.
    env = {"SYSTEMROOT": os.environ["SYSTEMROOT"]} if os.name == "nt" and "SYSTEMROOT" in os.environ else {}
    with tempfile.TemporaryDirectory(prefix="arena-code-") as tmp:
        path = Path(tmp) / "solve.py"
        path.write_text(code, encoding="utf-8")
        # -I isolated (no user site, no PYTHON* variables), -S no site import, -X utf8 UTF-8 output everywhere
        cmd = isolation_prefix() + [sys.executable, "-I", "-S", "-X", "utf8", "-c", launcher()]
        proc = subprocess.Popen(cmd, cwd=tmp, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, encoding="utf-8", errors="replace")
        _RUNNING.add(proc)
        try:
            stdout, stderr = proc.communicate(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            raise CodeError(f"timed out after {timeout_s:.0f} s") from None
        finally:
            _RUNNING.discard(proc)
    if proc.returncode != 0:
        raise CodeError(f"exit {proc.returncode}: {stderr.strip()[-300:]}")
    output = stdout.strip()[:MAX_OUTPUT]
    if not output:
        raise CodeError("the program printed nothing")
    if output.lower().rstrip(".") in DEGENERATE:
        raise CodeError(f"the program printed {output!r}, which is no answer")
    if _UNSET.search(output) and re.search(r"\d", output):
        # Python's None among numbers: values the program never filled in (seen on a futoshiki grid).
        # A text answer such as "None of the above" is not affected (a bare None is refused above).
        raise CodeError("the program printed None for values it left unset")
    return output
