"""Puzzle memory ("fingerprint"): which models got similar practiced puzzles right.

memory.json holds practiced puzzles (their text, cut short) and, per model, whether it answered each one
right in the model table, and how long it took. For a new challenge the most similar practiced puzzles are
found by the overlap of three-word shingles; only close matches count, so an unfamiliar kind of puzzle
changes nothing. From the matches the models are reordered: right most often first, then faster, then the
roster's order (the EvoRoute idea of success first, then duration); models the memory does not know follow,
and generally weak models stay last. When no model was right on most of the matches, the race starts one
racer wider.

Built by practice_arena/build_memory.py from the model table, on puzzles the practice race does not use.
Off by default (see load): switch it on with ARENA_MEMORY=on.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

MEMORY_FILE = Path(__file__).with_name("memory.json")
#: Measured on the 80 practice puzzles: puzzles of different types never overlapped more than 0.092; the
#: nearest same-type match was 0.2 to 0.9 for most types (free-form ones such as calendar sums lower).
SIMILAR_ENOUGH = 0.15
NEIGHBOURS = 5
HARD_BELOW = 0.5   # no model right on at least half of the matches: start the race one racer wider


@dataclass
class Hint:
    ranked: list[str]          # the models in the order to race
    hard: bool                 # no model was right on most of the matches
    matches: int
    similarity: float          # of the closest match
    rates: dict[str, float]    # model -> share of the matches it got right


def shingles(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {" ".join(words[i:i + 3]) for i in range(len(words) - 2)} or set(words)


def load(path: Path = MEMORY_FILE) -> list[dict[str, Any]]:
    """The memory entries, each with its shingles ready; [] unless ARENA_MEMORY=on, and when there is no
    usable file. Off by default: in a 30-puzzle race on unseen puzzles it lost 5 answers (23 of 30 against
    28 without it). On hard types every model was wrong in the model table, so it ranked fast failures first
    and its wider race ran into weak models whose quick wrong answers stopped the quick guess."""
    if os.environ.get("ARENA_MEMORY", "").strip().lower() != "on":
        return []
    try:
        entries = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    usable = [e for e in entries if isinstance(e, dict) and isinstance(e.get("text"), str)
              and isinstance(e.get("right"), dict)]
    for entry in usable:
        entry["_shingles"] = shingles(entry["text"])
    return usable


def recall(text: str, memory: list[dict[str, Any]], k: int = NEIGHBOURS,
           threshold: float = SIMILAR_ENOUGH) -> list[tuple[float, dict[str, Any]]]:
    """The k closest practiced puzzles at or above the threshold, closest first."""
    mine = shingles(text)
    scored = []
    for entry in memory:
        theirs = entry.get("_shingles") or shingles(entry["text"])
        similarity = len(mine & theirs) / max(1, len(mine | theirs))
        if similarity >= threshold:
            scored.append((similarity, entry))
    scored.sort(key=lambda pair: -pair[0])
    return scored[:k]


def advise(text: str, ranked: list[str], memory: list[dict[str, Any]],
           keep_last: tuple[str, ...] = ()) -> Hint | None:
    """A new racing order from the closest practiced puzzles, or None when nothing close is known: right
    most often first, then faster (mean seconds on the matches), then the roster's order. Models matching
    ``keep_last`` (slow or weak in general) stay at the end whatever the memory says."""
    near = recall(text, memory)
    if not near:
        return None
    rates: dict[str, float] = {}
    seconds: dict[str, float] = {}
    for model in ranked:
        seen = [float(entry["right"][model]) for _, entry in near if model in entry["right"]]
        if seen:
            rates[model] = sum(seen) / len(seen)
            times = [float(entry["seconds"][model]) for _, entry in near if model in entry.get("seconds", {})]
            seconds[model] = sum(times) / len(times) if times else float("inf")
    if not rates:   # none of today's models is in the memory
        return None
    position = {m: i for i, m in enumerate(ranked)}
    last = [m for m in ranked if any(k in m.lower() for k in keep_last)]
    known = sorted((m for m in rates if m not in last), key=lambda m: (-rates[m], seconds[m], position[m]))
    order = known + [m for m in ranked if m not in rates and m not in last] + last
    return Hint(ranked=order, hard=max(rates.values()) < HARD_BELOW, matches=len(near),
                similarity=round(near[0][0], 3), rates={m: round(r, 2) for m, r in rates.items()})
