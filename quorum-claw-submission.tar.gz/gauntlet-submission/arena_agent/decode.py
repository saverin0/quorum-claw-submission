"""Hidden text in a challenge: encoded runs in its text, and metadata or appended data in its files.

The event's own description of its text domain says "decoding", its image domain says "metadata or
anomalies", its audio domain "hidden triggers" and the server holds "encrypted data". A model never sees
raw bytes, and a base64 run in a question costs it tokens to guess at. So, before the models are asked:

* ``decode_text`` finds base64, hex, binary, URL-encoded, Morse and Caesar-shifted runs in the challenge
  text and clues and decodes them; what reads as text joins the clues ("Decoded from base64: ...").
  A decoded text is scanned once more (one level of nesting).
* ``read_data_uri`` opens a ``data:`` URI: PNG text chunks, JPEG comments and EXIF strings, WAV header,
  readable strings anywhere in the file, and anything appended after the file's proper end (a zip or a
  text hidden behind an image, with the zip's members listed and small text members read). Then the
  classic hiding places: text in the least significant bits of PNG pixels or of WAV samples, tone bursts
  in a WAV read as Morse code, and the metadata atoms of an MP4.

Standard library only, no network, bounded work (text up to 200 kB, files up to 8 MB), a few milliseconds.
Everything returned is advice for the models, never an answer by itself.
"""
from __future__ import annotations

import base64
import binascii
import io
import math
import re
import struct
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import zlib
from array import array
from html.parser import HTMLParser
from typing import Callable

MAX_TEXT = 200_000
MAX_FILE = 8_000_000
MAX_FINDINGS = 8
MAX_CHARS = 1500   # per finding, so the prompt stays small
FETCH_BYTES = 8_000_000  # a linked file is downloaded up to this size ...
FETCH_SECONDS = 5.0      # ... and within this time; otherwise the round goes on without it
MEDIA_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".wav", ".mp3", ".flac", ".ogg", ".m4a",
                    ".mp4", ".mov", ".webm", ".mkv", ".zip", ".txt", ".csv", ".json", ".log", ".pdf")
LSB_BYTES = 200_000     # pixel or sample bytes looked at for hidden bits: payloads sit at the start
LSB_MAX_CHARS = 512     # hidden text taken from the bits, at most
AUDIO_SECONDS = 60.0    # of a WAV looked at for tone bursts

#: Words that make a decoded run count as readable English (Caesar shifts and ROT13 need this: every shift
#: of letters is "printable").
COMMON_WORDS = frozenset((
    "the", "and", "is", "of", "to", "in", "a", "you", "it", "that", "for", "are", "with", "this", "answer", "what",
    "who", "which", "not", "on", "be", "or", "by", "as", "an", "from", "at", "your", "have", "was", "word",
    "secret", "key", "hidden", "code", "find", "number", "first", "last", "letter", "password", "flag", "message",
    "clue", "solve", "puzzle", "name", "one", "two", "three", "time", "use", "look", "here", "there"))

_BASE64 = re.compile(r"(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{16,}={0,2}(?![A-Za-z0-9+/_-])")
_HEX = re.compile(r"(?<![0-9A-Fa-f])(?:(?:0x)?[0-9A-Fa-f]{2}[ :,]?){8,}(?![0-9A-Fa-f])")
_BINARY = re.compile(r"(?<![01])(?:[01]{8}[ ,]?){4,}(?![01])")
_URLENC = re.compile(r"(?:[A-Za-z0-9_.~-]*%[0-9A-Fa-f]{2}){3,}[A-Za-z0-9_.~%-]*")
_MORSE = re.compile(r"(?<![.\-])[.\-]{1,6}(?:[ /]+[.\-]{1,6}){3,}(?![.\-])")
_LETTER_RUN = re.compile(r"[A-Za-z][A-Za-z' ]{19,}")
_DATA_URI = re.compile(r"data:[\w.+-]+/[\w.+-]+(?:;[\w=-]+)*;base64,[A-Za-z0-9+/=]+")   # no spaces: prose must not be eaten
_WORD = re.compile(r"[A-Za-z']+")
_STRINGS = re.compile(rb"[\x20-\x7e]{8,}")

MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H", "..": "I",
    ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R",
    "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z",
    "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7",
    "---..": "8", "----.": "9", ".-.-.-": ".", "--..--": ",", "..--..": "?", "-....-": "-", "-..-.": "/"}


def common_words(text: str) -> int:
    return sum(1 for w in _WORD.findall(text.lower()) if w in COMMON_WORDS)


def readable(data: bytes) -> str | None:
    """The bytes as text when they read as text: valid UTF-8, mostly printable, at least one letter."""
    if len(data) < 4:
        return None
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    printable = sum(1 for ch in text if ch.isprintable() or ch in "\r\n\t")
    if printable < 0.9 * len(text) or len({ch.lower() for ch in text if ch.isalpha()}) < 3:
        return None   # "ffff" from a run of digits read as hex is not a message; three distinct letters are
    return text.strip()


def _b64(run: str) -> bytes | None:
    body = run.rstrip("=")
    body += "=" * (-len(body) % 4)
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            return decoder(body)
        except (binascii.Error, ValueError):
            continue
    return None


def _caesar(run: str) -> tuple[str, str] | None:
    """The shift that turns a run of letters into English, when one does, as (name, text)."""
    best, best_text, base = 0, "", common_words(run)
    for shift in range(1, 26):
        shifted = "".join(chr((ord(c) - 65 + shift) % 26 + 65) if c.isupper()
                          else chr((ord(c) - 97 + shift) % 26 + 97) if c.islower() else c for c in run)
        score = common_words(shifted)
        if score > best:
            best, best_text, best_shift = score, shifted, shift
    if best >= 3 and best > base:
        return ("ROT13" if best_shift == 13 else f"Caesar shift {best_shift}"), best_text
    return None


def _morse(run: str) -> str | None:
    words = re.split(r"\s*/\s*|\s{2,}", run.strip())
    out = []
    for word in words:
        letters = [MORSE.get(sym) for sym in word.split()]
        if not letters or any(ch is None for ch in letters):
            return None
        out.append("".join(letters))   # type: ignore[arg-type]
    text = " ".join(out)
    return text if len(text) >= 3 else None


def decode_text(text: str, nested: bool = True) -> list[str]:
    """Readable decodings of encoded runs in ``text``, as "Decoded from <how>: <text>" lines. Never raises."""
    try:
        return _decode_text(text, nested)
    except Exception:  # noqa: BLE001 - odd text must not end a round
        return []


def _decode_text(text: str, nested: bool) -> list[str]:
    text = _DATA_URI.sub(" ", text[:MAX_TEXT])   # file payloads are read by read_data_uri, not as text
    found: list[str] = []
    seen: set[str] = set()

    def add(how: str, decoded: str) -> None:
        decoded = decoded.strip()
        if decoded and decoded not in seen and decoded not in text and len(found) < MAX_FINDINGS:
            seen.add(decoded)
            found.append(f"Decoded from {how}: {decoded[:MAX_CHARS]}")
            if nested:
                for deeper in _decode_text(decoded, nested=False):
                    if len(found) < MAX_FINDINGS:
                        found.append(deeper.replace("Decoded from", f"Decoded from {how}, then", 1))

    for run in _BASE64.findall(text):
        if run.isdigit() or run.isalpha() and run.islower() or run.isalpha() and run.isupper():
            continue   # a plain word or number, not base64
        raw = _b64(run)
        if raw is not None and (as_text := readable(raw)) is not None:
            add("base64", as_text)
    for run in _HEX.findall(text):
        cleaned = re.sub(r"0x|[ :,]", "", run)
        if len(cleaned) % 2 or cleaned.isdigit():
            continue   # a plain number is not hex
        try:
            raw = bytes.fromhex(cleaned)
        except ValueError:
            continue
        if (as_text := readable(raw)) is not None:
            add("hex", as_text)
    for run in _BINARY.findall(text):
        bits = re.sub(r"[ ,]", "", run)
        raw = int(bits, 2).to_bytes(len(bits) // 8, "big")
        if (as_text := readable(raw)) is not None:
            add("binary", as_text)
    for run in _URLENC.findall(text):
        decoded = urllib.parse.unquote(run)
        if decoded != run and readable(decoded.encode("utf-8")) is not None:
            add("URL encoding", decoded)
    for run in _MORSE.findall(text):
        decoded = _morse(run)
        if decoded is not None:
            add("Morse code", decoded)
    for run in _LETTER_RUN.findall(text):
        if common_words(run) >= 3:
            continue   # already English
        shifted = _caesar(run)
        if shifted is not None:
            add(shifted[0], shifted[1])
    return found


# ---------------------------------------------------------------------------- files behind data: URIs

def _strings(data: bytes, limit: int = 12) -> list[str]:
    out: list[str] = []
    for match in _STRINGS.finditer(data):
        s = match.group().decode("ascii").strip()
        if s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out


def _png(data: bytes) -> tuple[list[str], int]:
    """(findings, end offset) for a PNG: its text chunks and where the image proper ends."""
    out, pos = [], 8
    while pos + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + length]
        if kind == b"tEXt":
            key, _, value = body.partition(b"\x00")
            out.append(f"PNG text chunk {key.decode('latin-1')}: {value.decode('latin-1', 'replace')[:MAX_CHARS]}")
        elif kind == b"zTXt":
            key, _, rest = body.partition(b"\x00")
            try:
                value = zlib.decompress(rest[1:]).decode("latin-1", "replace")
                out.append(f"PNG compressed text chunk {key.decode('latin-1')}: {value[:MAX_CHARS]}")
            except zlib.error:
                pass
        elif kind == b"iTXt":
            key, _, rest = body.partition(b"\x00")
            value = rest.split(b"\x00", 3)[-1] if rest[:1] == b"\x00" else rest
            out.append(f"PNG international text chunk {key.decode('latin-1')}: "
                       f"{value.decode('utf-8', 'replace')[:MAX_CHARS]}")
        pos += 12 + length
        if kind == b"IEND":
            return out, pos
    return out, len(data)


def _jpeg(data: bytes) -> tuple[list[str], int]:
    """(findings, end offset) for a JPEG: comment segments, strings in EXIF, where the image ends."""
    out, pos = [], 2
    while pos + 4 <= len(data) and data[pos] == 0xFF:
        marker = data[pos + 1]
        if marker == 0xD9:   # end of image
            return out, pos + 2
        if marker == 0xDA:   # scan data: the end marker is somewhere after it
            end = data.find(b"\xff\xd9", pos)
            return out, (end + 2 if end >= 0 else len(data))
        length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
        body = data[pos + 4:pos + 2 + length]
        if marker == 0xFE:
            out.append(f"JPEG comment: {body.decode('utf-8', 'replace')[:MAX_CHARS]}")
        elif marker == 0xE1 and body.startswith(b"Exif"):
            strings = [s for s in _strings(body) if s not in ("Exif",)]
            if strings:
                out.append("JPEG EXIF strings: " + "; ".join(strings)[:MAX_CHARS])
        pos += 2 + length
    return out, len(data)


def _wav(data: bytes) -> tuple[list[str], int]:
    out = []
    if len(data) >= 36 and data[12:16] == b"fmt ":
        channels, rate = struct.unpack("<HI", data[22:28])
        bits = struct.unpack("<H", data[34:36])[0]
        size = struct.unpack("<I", data[4:8])[0] + 8
        pos, seconds = 12, None
        while pos + 8 <= min(len(data), size):
            kind, length = struct.unpack("<4sI", data[pos:pos + 8])
            if kind == b"data" and channels and rate and bits:
                seconds = length / (rate * channels * bits / 8)
            elif kind == b"LIST":
                strings = _strings(data[pos + 8:pos + 8 + length])
                if strings:
                    out.append("WAV info: " + "; ".join(strings)[:MAX_CHARS])
            pos += 8 + length + (length % 2)
        out.insert(0, f"WAV audio: {channels} channel(s), {rate} Hz, {bits} bit"
                      + (f", {seconds:.1f} s" if seconds else ""))
        return out, min(size, len(data))
    return out, len(data)


def _zip_members(data: bytes) -> list[str]:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            out = ["zip archive with: " + ", ".join(i.filename for i in archive.infolist()[:20])]
            for info in archive.infolist()[:5]:
                if info.file_size <= 20_000 and not info.is_dir():
                    text = readable(archive.read(info))
                    if text is not None:
                        out.append(f"zip member {info.filename}: {text[:MAX_CHARS]}")
            return out
    except (zipfile.BadZipFile, RuntimeError, ValueError):
        return []


# ---------------------------------------------------------------------------- the classic hiding places

def _printable_prefix(data: bytes) -> str:
    """The run of printable characters at the start of ``data`` (at least 6), or ''."""
    end = 0
    while end < len(data) and (32 <= data[end] < 127 or data[end] in (9, 10, 13)):
        end += 1
    text = data[:end].decode("ascii").strip()
    wordlike = sum(1 for c in text if c.isalnum() or c == " ")
    # Random bits make short printable runs too: eight characters, mostly letters, digits and spaces, is the bar.
    return text if len(text) >= 8 and wordlike >= 0.7 * len(text) and len({c.lower() for c in text if c.isalpha()}) >= 3 else ""


def _bits_to_text(bits: list[int]) -> list[str]:
    """Text spelled by a bit sequence, trying both bit orders inside a byte; ends at the first unprintable."""
    out = []
    for order in ("msb first", "lsb first"):
        chunk = bytearray()
        for i in range(0, min(len(bits), 8 * LSB_MAX_CHARS) - 7, 8):
            byte = bits[i:i + 8] if order == "msb first" else bits[i:i + 8][::-1]
            chunk.append(sum(b << (7 - j) for j, b in enumerate(byte)))
        text = _printable_prefix(bytes(chunk))
        if text:
            out.append(f"{text[:MAX_CHARS]} ({order})")
    return out


def _png_pixels(data: bytes) -> tuple[bytes, int] | None:
    """The first rows of an 8-bit, non-interlaced PNG as unfiltered pixel bytes, with the channel count."""
    if len(data) < 33 or data[12:16] != b"IHDR":
        return None
    width, height, depth, colour, _, _, interlace = struct.unpack(">IIBBBBB", data[16:29])
    channels = {0: 1, 2: 3, 4: 2, 6: 4}.get(colour)
    if depth != 8 or interlace != 0 or channels is None or width == 0:
        return None
    idat, pos = [], 8
    while pos + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[pos:pos + 8])
        if kind == b"IDAT":
            idat.append(data[pos + 8:pos + 8 + length])
        pos += 12 + length
        if kind == b"IEND" or sum(map(len, idat)) > LSB_BYTES * 2:
            break
    try:
        raw = zlib.decompressobj().decompress(b"".join(idat), LSB_BYTES + width * channels + 64)
    except zlib.error:
        return None
    stride = width * channels
    out, prev, pos = bytearray(), bytearray(stride), 0
    while pos + 1 + stride <= len(raw) and len(out) < LSB_BYTES:
        method, line = raw[pos], bytearray(raw[pos + 1:pos + 1 + stride])
        pos += 1 + stride
        if method == 1:
            for i in range(channels, stride):
                line[i] = (line[i] + line[i - channels]) & 255
        elif method == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif method == 3:
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 255
        elif method == 4:
            for i in range(stride):
                a = line[i - channels] if i >= channels else 0
                b, c = prev[i], (prev[i - channels] if i >= channels else 0)
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[i] = (line[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        elif method != 0:
            return None
        out += line
        prev = line
    return bytes(out), channels


def _png_lsb(data: bytes) -> list[str]:
    """Text in the least significant bits of the pixels: every channel in order, and each colour alone."""
    pixels = _png_pixels(data)
    if pixels is None:
        return []
    raw, channels = pixels
    layouts = {"all channels": raw}
    if channels >= 3:
        for index, name in enumerate(("red", "green", "blue")):
            layouts[name] = raw[index::channels]
    out = []
    for name, seq in layouts.items():
        for text in _bits_to_text([b & 1 for b in seq[:8 * LSB_MAX_CHARS]]):
            out.append(f"text in the PNG pixel bits ({name}): {text}")
    return out


def _wav_samples(data: bytes, end: int) -> tuple[array, int, int] | None:
    """(samples of the first channel, sample rate, channels) of a 16-bit or 8-bit PCM WAV, cut to AUDIO_SECONDS."""
    if len(data) < 36 or data[12:16] != b"fmt ":
        return None
    fmt_tag, channels, rate = struct.unpack("<HHI", data[20:28])
    bits = struct.unpack("<H", data[34:36])[0]
    if fmt_tag != 1 or channels == 0 or rate == 0 or bits not in (8, 16):
        return None
    pos = 12
    while pos + 8 <= min(end, len(data)):
        kind, length = struct.unpack("<4sI", data[pos:pos + 8])
        if kind == b"data":
            frames = int(min(length, AUDIO_SECONDS * rate * channels * bits // 8))
            body = data[pos + 8:pos + 8 + frames]
            samples = array("h") if bits == 16 else array("B")
            samples.frombytes(body[:len(body) - len(body) % samples.itemsize])
            if bits == 8:
                samples = array("h", [(s - 128) << 8 for s in samples])
            return samples[::channels], rate, channels
        pos += 8 + length + (length % 2)
    return None


def _wav_lsb(samples: array) -> list[str]:
    return [f"text in the WAV sample bits: {t}" for t in _bits_to_text([s & 1 for s in samples[:8 * LSB_MAX_CHARS]])]


DTMF_LOW = (697, 770, 852, 941)
DTMF_HIGH = (1209, 1336, 1477, 1633)
DTMF_KEYS = {(697, 1209): "1", (697, 1336): "2", (697, 1477): "3", (697, 1633): "A",
             (770, 1209): "4", (770, 1336): "5", (770, 1477): "6", (770, 1633): "B",
             (852, 1209): "7", (852, 1336): "8", (852, 1477): "9", (852, 1633): "C",
             (941, 1209): "*", (941, 1336): "0", (941, 1477): "#", (941, 1633): "D"}


def _goertzel(samples: array, rate: int, hz: float) -> float:
    """Power of one frequency in the samples (the Goertzel algorithm: no FFT needed for a few tones)."""
    n = len(samples)
    if n == 0:
        return 0.0
    k = int(0.5 + n * hz / rate)
    coeff = 2.0 * math.cos(2.0 * math.pi * k / n)
    s1 = s2 = 0.0
    for x in samples:
        s0 = x + coeff * s1 - s2
        s2, s1 = s1, s0
    return s2 * s2 + s1 * s1 - coeff * s1 * s2


def _dtmf(samples: array, rate: int, bursts: list[tuple[int, int]], window: int) -> str:
    """The keypad digits the tone bursts spell, when every burst is a clear pair of DTMF tones; else ''."""
    digits = []
    for start, length in bursts[:24]:
        trim = length // 5
        segment = samples[(start + trim) * window:(start + length - trim) * window][:4000]
        if len(segment) < 40:
            return ""
        low = {f: _goertzel(segment, rate, f) for f in DTMF_LOW}
        high = {f: _goertzel(segment, rate, f) for f in DTMF_HIGH}
        lows, highs = sorted(low.values(), reverse=True), sorted(high.values(), reverse=True)
        if lows[0] <= 2.5 * (lows[1] + 1e-9) or highs[0] <= 2.5 * (highs[1] + 1e-9):
            return ""
        digit = DTMF_KEYS.get((max(low, key=low.get), max(high, key=high.get)))
        if digit is None:
            return ""
        digits.append(digit)
    return "".join(digits) if len(digits) >= 2 else ""


def _wav_tones(samples: array, rate: int) -> list[str]:
    """Tone bursts in the audio (beeps), with their timing, and the Morse code they spell when they do."""
    window = max(1, rate // 100)   # 10 ms
    step = 4 if len(samples) > 400_000 else 1
    levels = []
    for start in range(0, len(samples) - window, window):
        chunk = samples[start:start + window:step]
        levels.append(math.sqrt(sum(s * s for s in chunk) / max(1, len(chunk))))
    if not levels:
        return []
    top = max(levels)
    if top < 300:   # silence
        return []
    threshold = top * 0.3
    runs: list[tuple[bool, int, int]] = []   # (loud, start window, length in windows)
    for i, level in enumerate(levels):
        loud = level >= threshold
        if runs and runs[-1][0] == loud:
            runs[-1] = (loud, runs[-1][1], runs[-1][2] + 1)
        else:
            runs.append((loud, i, 1))
    bursts = [(s, n) for loud, s, n in runs if loud]
    if len(bursts) < 2:
        return []
    out = [f"{len(bursts)} tone bursts in the audio between {bursts[0][0] / 100:.2f} s and "
           f"{(bursts[-1][0] + bursts[-1][1]) / 100:.2f} s"]
    keys = _dtmf(samples, rate, bursts, window)
    if keys:   # touch-tones: two frequencies per burst, a keypad digit each
        out.append(f"DTMF keypad tones in the audio: {keys}")
        return out
    # Morse: the shortest burst is a dot; a dash is at least twice as long; gaps part letters and words.
    unit = min(n for _, n in bursts)
    letters, word, symbol = [], [], ""
    for index, (loud, start, length) in enumerate(runs):
        if loud:
            symbol += "-" if length >= 2 * unit else "."
        elif symbol and index < len(runs) - 1:
            if length >= 2 * unit:
                word.append(symbol)
                symbol = ""
            if length >= 5 * unit:
                letters.append(word)
                word = []
    if symbol:
        word.append(symbol)
    if word:
        letters.append(word)
    decoded = " ".join("".join(MORSE.get(sym, "?") for sym in w) for w in letters)
    if sum(ch.isalnum() for ch in decoded) >= 3 and "?" not in decoded:   # speech makes bursts too, not letters
        out.append(f"Morse code in the audio: {decoded}")
    return out


def _mp4(data: bytes) -> list[str]:
    """Metadata atoms of an MP4 or MOV: tags under ilst, track handler types, readable strings."""
    out, tracks, tags = [], [], []
    containers = {b"moov", b"trak", b"mdia", b"minf", b"stbl", b"udta", b"meta", b"ilst", b"edts"}

    def walk(start: int, end: int, depth: int, inside_ilst: bool) -> None:
        pos = start
        while pos + 8 <= end and depth < 8:
            size, kind = struct.unpack(">I4s", data[pos:pos + 8])
            head = 8
            if size == 1:
                size, head = struct.unpack(">Q", data[pos + 8:pos + 16])[0], 16
            elif size == 0:
                size = end - pos
            if size < head:
                return
            body, body_end = pos + head, min(pos + size, end)
            if kind == b"hdlr" and body + 12 <= body_end:
                tracks.append(data[body + 8:body + 12].decode("latin-1"))
            elif inside_ilst and kind == b"data" and body + 8 <= body_end:
                text = readable(data[body + 8:body_end])
                if text:
                    tags.append(text[:300])
            elif kind in containers or inside_ilst:   # an ilst item (\xa9cmt, \xa9nam ...) holds a data box
                walk(body + (4 if kind == b"meta" else 0), body_end, depth + 1, kind == b"ilst" or inside_ilst)
            pos += size

    walk(0, len(data), 0, False)
    if tracks:
        names = {"vide": "video", "soun": "audio", "text": "text", "sbtl": "subtitle", "subt": "subtitle"}
        out.append("MP4 tracks: " + ", ".join(names.get(t, t) for t in tracks))
    if tags:
        out.append("MP4 tags: " + "; ".join(tags)[:MAX_CHARS])
    strings = [s for s in _strings(data, 24) if len(s) >= 12 and s not in tags]   # subtitle samples live in mdat
    if strings:
        out.append("readable strings in the MP4: " + "; ".join(strings[:12])[:MAX_CHARS])
    return out


def _quietly(fn: Callable[..., list[str]], *args: object) -> list[str]:
    """A reader's findings, or none: a malformed file must never raise out of the decoder (a round would be lost)."""
    try:
        return list(fn(*args))
    except Exception:  # noqa: BLE001 - the file is the arena's, its layout is not under our control
        return []


def read_bytes(data: bytes, kind: str = "") -> list[str]:
    """What a file says besides its picture or sound: metadata, readable strings, appended data, and the
    classic hiding places (pixel and sample bits, tone bursts, MP4 atoms). Never raises."""
    try:
        return _read_bytes(data[:MAX_FILE], kind)
    except Exception:  # noqa: BLE001
        return []


def _read_bytes(data: bytes, kind: str) -> list[str]:
    out: list[str] = []
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        out, end = _png(data)
        out += _quietly(_png_lsb, data)
    elif data.startswith(b"\xff\xd8"):
        out, end = _jpeg(data)
    elif data.startswith(b"RIFF") and data[8:12] == b"WAVE":
        out, end = _wav(data)
        audio = _wav_samples(data, end)
        if audio is not None:
            samples, rate, _channels = audio
            out += _quietly(_wav_lsb, samples) + _quietly(_wav_tones, samples, rate)
    elif data.startswith(b"PK\x03\x04"):
        return _zip_members(data)
    elif data[4:8] == b"ftyp":
        out, end = _quietly(_mp4, data), len(data)
    elif data.startswith(b"ID3") or data[:2] == b"\xff\xfb" or data[:2] == b"\xff\xf3":
        out, end = _quietly(_mp3, data), len(data)
    elif data.startswith(b"fLaC"):
        out, end = _quietly(_flac, data), len(data)
    elif data.startswith(b"OggS"):
        out, end = _quietly(_ogg, data), len(data)
    else:
        end = len(data)
        strings = _strings(data)
        if strings:
            out.append(f"readable strings in the {kind or 'file'}: " + "; ".join(strings)[:MAX_CHARS])
    tail = data[end:]
    if tail.strip(b"\x00"):
        out.append(f"{len(tail)} bytes appended after the {kind or 'file'}'s end")
        if tail.startswith(b"PK\x03\x04"):
            out += _zip_members(tail)
        elif (text := readable(tail)) is not None:
            out.append(f"appended text: {text[:MAX_CHARS]}")
        else:
            strings = _strings(tail)
            if strings:
                out.append("readable strings in the appended data: " + "; ".join(strings)[:MAX_CHARS])
    for line in list(out):   # an encoded run inside metadata is decoded too
        out += decode_text(line, nested=False)
    return out[:MAX_FINDINGS]


def looks_like_file_link(value: str, key: str = "") -> bool:
    """An http(s) link that points at a file: a media extension, or a field named like an attachment."""
    low = value.lower().split("?")[0]
    if not low.startswith(("http://", "https://")):
        return False
    return low.endswith(MEDIA_EXTENSIONS) or any(k in key.lower() for k in ("uri", "url", "file", "attach", "audio",
                                                                             "video", "image", "media", "download"))


def _download(url: str) -> tuple[str, bytes]:
    """A link's content type (lower case, no parameters) and bytes, within FETCH_SECONDS and up to FETCH_BYTES;
    ('', b'') when nothing arrives."""
    if not url.lower().startswith(("http://", "https://")):
        return "", b""
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "arena-agent/1.0", "Accept": "*/*"})
        with urllib.request.urlopen(request, timeout=FETCH_SECONDS) as response:
            kind = str(response.headers.get("Content-Type") or "application/octet-stream").split(";")[0].strip()
            data = response.read(FETCH_BYTES + 1)
    except (OSError, ValueError):
        return "", b""
    return kind.lower(), data[:FETCH_BYTES]


def fetch_uri(url: str) -> str:
    """A linked file as a data: URI, downloaded within FETCH_SECONDS and up to FETCH_BYTES; '' otherwise."""
    kind, data = _download(url)
    if not kind:
        return ""
    if kind == "application/octet-stream":   # name the kind by its bytes when the server did not
        guess = {b"\x89PNG": "image/png", b"\xff\xd8": "image/jpeg", b"RIFF": "audio/wav", b"ID3": "audio/mpeg",
                 b"fLaC": "audio/flac", b"OggS": "audio/ogg", b"PK\x03\x04": "application/zip"}
        for magic, name in guess.items():
            if data.startswith(magic):
                kind = name
                break
        if data[4:8] == b"ftyp":
            kind = "video/mp4"
    return f"data:{kind};base64,{base64.b64encode(data).decode('ascii')}"


PAGE_CHARS = 8000        # text kept from a fetched web page, at most (about 2k tokens)
_LINK = re.compile(r"https?://[^\s<>\"'()\[\]{}]+")
_TEXT_KINDS = ("text/", "application/json", "application/xml", "application/xhtml")
_BLOCK_TAGS = {"p", "div", "br", "li", "tr", "td", "th", "h1", "h2", "h3", "h4", "h5", "h6", "title", "pre",
               "section", "article", "header", "footer", "nav", "ul", "ol", "table", "blockquote", "dt", "dd"}
_SKIP_TAGS = {"script", "style", "noscript", "template"}


def links_in(text: str) -> list[str]:
    """Every http(s) link written in a text, in order, each once, trailing punctuation dropped."""
    out: list[str] = []
    for found in _LINK.findall(text):
        link = found.rstrip(".,;:!?")
        if link not in out:
            out.append(link)
    return out


def page_links(text: str) -> list[str]:
    """The links in a text that point at pages rather than files (files go through fetch_uri)."""
    return [link for link in links_in(text) if not looks_like_file_link(link)]


class _PageText(HTMLParser):
    """The readable text of an HTML page: its title and words, one line per block; scripts and styles left out."""

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in _SKIP_TAGS:
            self.skip += 1
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in _SKIP_TAGS:
            self.skip = max(0, self.skip - 1)
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skip:
            self.parts.append(data)


def page_text(data: bytes, kind: str) -> str:
    """Readable text from a page's bytes: HTML stripped to its words, other text as it is; spaces collapsed,
    empty lines dropped, capped at PAGE_CHARS."""
    text = data.decode("utf-8", errors="replace")
    if "html" in kind or text.lstrip()[:200].lower().startswith(("<!doctype html", "<html")):
        parser = _PageText()
        try:
            parser.feed(text)
            parser.close()
        except Exception:  # noqa: BLE001 - a broken page: whatever was read before the break
            pass
        text = "".join(parser.parts)
    lines = [re.sub(r"[ \t\r\f\v]+", " ", line).strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line)[:PAGE_CHARS]


def fetch_page(url: str) -> str:
    """The readable text of the page at a link, within FETCH_SECONDS and up to FETCH_BYTES; '' when nothing
    arrives or what arrives is not text (a file goes through fetch_uri instead)."""
    kind, data = _download(url)
    if not kind or not kind.startswith(_TEXT_KINDS):
        return ""
    return page_text(data, kind)


def _syncsafe(raw: bytes) -> int:
    return (raw[0] << 21) | (raw[1] << 14) | (raw[2] << 7) | raw[3]


def _id3_text(raw: bytes) -> str:
    """The text of an ID3v2 text frame: first byte names the encoding."""
    if not raw:
        return ""
    encoding = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(raw[0], "latin-1")
    return raw[1:].decode(encoding, "replace").replace("\x00", " ").strip()


def _mp3(data: bytes) -> list[str]:
    """ID3v2 frames at the start and the ID3v1 tag at the end of an MP3: titles, comments, custom text."""
    out, tags = [], []
    if data.startswith(b"ID3") and len(data) >= 10:
        version = data[3]
        size = _syncsafe(data[6:10])
        pos, end = 10, min(10 + size, len(data))
        while pos + 10 <= end:
            frame_id = data[pos:pos + 4]
            if not frame_id.strip(b"\x00"):
                break
            length = _syncsafe(data[pos + 4:pos + 8]) if version >= 4 else struct.unpack(">I", data[pos + 4:pos + 8])[0]
            body = data[pos + 10:pos + 10 + length]
            name = frame_id.decode("latin-1", "replace")
            if name == "COMM" and len(body) > 4:
                text = _id3_text(body[:1] + body[4:])
                tags.append(f"comment: {text}")
            elif name == "TXXX":
                tags.append(f"text: {_id3_text(body)}")
            elif name.startswith("T"):
                tags.append(f"{name}: {_id3_text(body)}")
            elif name in ("USLT", "GEOB", "PRIV"):
                text = readable(body[4:]) if name == "USLT" else readable(body)
                if text:
                    tags.append(f"{name}: {text[:300]}")
            pos += 10 + length
    if len(data) >= 128 and data[-128:-125] == b"TAG":
        trailer = data[-125:]
        fields = (trailer[:30], trailer[30:60], trailer[60:90], trailer[94:124])
        text = "; ".join(f.decode("latin-1", "replace").strip("\x00 ") for f in fields if f.strip(b"\x00 "))
        if text:
            tags.append(f"ID3v1: {text}")
    if tags:
        out.append("MP3 tags: " + "; ".join(t for t in tags if t)[:MAX_CHARS])
    return out


def _vorbis_comments(raw: bytes) -> list[str]:
    """KEY=value comments of a Vorbis comment block (FLAC and OGG)."""
    if len(raw) < 8:
        return []
    vendor_len = struct.unpack("<I", raw[:4])[0]
    pos = 4 + vendor_len
    if pos + 4 > len(raw):
        return []
    count = struct.unpack("<I", raw[pos:pos + 4])[0]
    pos += 4
    out = []
    for _ in range(min(count, 64)):
        if pos + 4 > len(raw):
            break
        length = struct.unpack("<I", raw[pos:pos + 4])[0]
        out.append(raw[pos + 4:pos + 4 + length].decode("utf-8", "replace"))
        pos += 4 + length
    return out


def _flac(data: bytes) -> list[str]:
    pos, comments = 4, []
    while pos + 4 <= len(data):
        header = data[pos]
        block_type, length = header & 0x7F, int.from_bytes(data[pos + 1:pos + 4], "big")
        if block_type == 4:
            comments += _vorbis_comments(data[pos + 4:pos + 4 + length])
        pos += 4 + length
        if header & 0x80:
            break
    return ["FLAC tags: " + "; ".join(comments)[:MAX_CHARS]] if comments else []


def _ogg(data: bytes) -> list[str]:
    marker = data.find(b"\x03vorbis")
    if marker < 0:
        marker = data.find(b"OpusTags")
        if marker < 0:
            return []
        comments = _vorbis_comments(data[marker + 8:marker + 8 + 65536])
    else:
        comments = _vorbis_comments(data[marker + 7:marker + 7 + 65536])
    return ["OGG tags: " + "; ".join(comments)[:MAX_CHARS]] if comments else []


def read_data_uri(uri: str) -> list[str]:
    """Findings for one ``data:<mime>;base64,...`` URI; empty for anything else."""
    if not uri.startswith("data:") or ";base64," not in uri[:200]:
        return []
    head, _, payload = uri.partition(";base64,")
    kind = head[5:].split(";")[0] or "file"
    try:
        data = base64.b64decode(re.sub(r"\s+", "", payload)[:MAX_FILE * 4 // 3 + 4], validate=False)
    except (binascii.Error, ValueError):
        return []
    return [f"{kind}: {line}" for line in read_bytes(data, kind)]


# ---------------------------------------------------------------------------- long texts (logs)

DIGEST_LINES = 120       # a text with at least this many lines gets a digest
_NEGATIVE = re.compile(r"(?:^|[\s(=:,])-\d+(?:\.\d+)?(?![\d-])")   # not the dashes of a date
_POSITIVE = re.compile(r"(?:^|[\s(=:,])\d+(?:\.\d+)?\b")
_CLOCK = re.compile(r"\b(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?|\d{2}:\d{2}:\d{2})")
DIGEST_UNIQUE = 12       # lines whose pattern occurs once, listed at most
PROMPT_CHARS = 60_000    # a description longer than this is cut for the models (about 15k tokens)
_MASKS = (
    (re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b"), "<ip>"),
    (re.compile(r"\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?(?:\.\d+)?Z?\b"), "<time>"),
    (re.compile(r"\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b"), "<time>"),
    (re.compile(r"\b[0-9a-f]{6,}\b", re.I), "<hex>"),
    (re.compile(r"/[\w./-]+"), "<path>"),
    (re.compile(r"\d+"), "<n>"),   # also inside words: user7, sshd[4412]
)


def line_pattern(line: str) -> str:
    """The line with its variable parts masked: addresses, times, hex ids, paths and numbers."""
    for regex, tag in _MASKS:
        line = regex.sub(tag, line)
    return " ".join(line.split())


def digest_text(text: str) -> list[str]:
    """For a long text such as a log: how many lines and patterns, the lines whose pattern occurs only once
    (numbered, so an answer can point at them), and the most common patterns. Empty for short texts. Never raises."""
    try:
        return _digest_text(text)
    except Exception:  # noqa: BLE001
        return []


def _digest_text(text: str) -> list[str]:
    lines = [(number, line) for number, line in enumerate(text.splitlines(), 1) if line.strip()]
    if len(lines) < DIGEST_LINES:
        return []
    patterns = [line_pattern(line) for _, line in lines]
    counts: dict[str, int] = {}
    for pattern in patterns:
        counts[pattern] = counts.get(pattern, 0) + 1
    unique = [(number, line) for (number, line), pattern in zip(lines, patterns) if counts[pattern] == 1]
    out = [f"Text digest: {len(lines)} lines, {len(counts)} distinct line patterns once addresses, times, ids and "
           f"numbers are masked."]
    if unique:
        shown = "; ".join(f"line {number}: {line.strip()[:200]}" for number, line in unique[:DIGEST_UNIQUE])
        more = f" (and {len(unique) - DIGEST_UNIQUE} more)" if len(unique) > DIGEST_UNIQUE else ""
        out.append(f"Lines whose pattern occurs only once{more}: {shown}")
    common = sorted(counts.items(), key=lambda item: -item[1])[:5]
    out.append("Most common patterns: " + "; ".join(f"{count} x {pattern[:100]}" for pattern, count in common))
    # Two value checks the patterns cannot see in a uniform log: a rare negative number, a clock going back.
    negatives = [(number, line) for number, line in lines if _NEGATIVE.search(line)]
    with_numbers = sum(1 for _, line in lines if _POSITIVE.search(line))
    if 0 < len(negatives) <= 5 and with_numbers >= 20:
        out.append("Lines with a negative number, rare here: "
                   + "; ".join(f"line {number}: {line.strip()[:160]}" for number, line in negatives))
    previous, backwards = None, []
    for number, line in lines:
        found = _CLOCK.search(line)
        if found:
            stamp = found.group(1)
            if previous is not None and len(stamp) == len(previous) and stamp < previous:
                backwards.append((number, line))
            previous = stamp
    if 0 < len(backwards) <= 5:
        out.append("Lines whose time goes backwards: "
                   + "; ".join(f"line {number}: {line.strip()[:160]}" for number, line in backwards))
    return out


def trim_text(text: str) -> str:
    """The text cut to PROMPT_CHARS for a prompt: the start, a note, the end. The digest covers the middle."""
    if len(text) <= PROMPT_CHARS:
        return text
    head, tail = PROMPT_CHARS * 2 // 3, PROMPT_CHARS // 3
    return (text[:head] + f"\n[... {len(text) - head - tail} characters left out here; the text digest in the clues "
            "covers the whole text ...]\n" + text[-tail:])


# ---------------------------------------------------------------------------- drawings in text

ART_MIN_LINES = 4
ART_CELL = (12, 20)  # pixels per character cell when a drawing is rendered: big, solid strokes. At 6 by 10 with
#: grid gaps (a 400 px wide picture) Super VL dropped a doubled letter and misread a 6-row font.
_READING = re.compile(r"\b(what|which) (word|words|text|letters?|phrase|message|name)\b"
                      r"|\b(does|do) (this|it|these|the \w+) (say|read|spell)\b|\bwhat is written\b"
                      r"|\b(read|transcribe) (the|this) (word|text|banner|drawing|letters|message)\b"
                      r"|\bspell(s|ed)? out\b", re.I)


def reading_task(text: str) -> bool:
    """Does the question ask what a drawing says (a banner font to read) rather than to solve what it shows?"""
    return bool(_READING.search(text))


def ascii_art(text: str) -> str:
    """The largest block of drawing in a text: at least ART_MIN_LINES consecutive lines whose ink is mostly
    symbols with hardly any letters or digits (a banner font, box art). Number grids are not drawings."""
    best: list[str] = []
    current: list[str] = []

    def drawn(block: list[str]) -> int:
        return sum(1 for line in block if line.strip())

    for line in text.splitlines():
        ink = [ch for ch in line if not ch.isspace()]
        symbols = sum(1 for ch in ink if not ch.isalnum())
        if ink and symbols >= 0.6 * len(ink) and len(ink) - symbols <= 0.15 * len(ink):
            current.append(line)
        elif current and not line.strip():
            current.append(line)
        else:
            if drawn(current) > drawn(best):
                best = current
            current = []
    if drawn(current) > drawn(best):
        best = current
    art = "\n".join(best).strip("\n")
    return art if drawn(art.splitlines()) >= ART_MIN_LINES and sum(1 for ch in art if not ch.isspace()) >= 20 else ""


def render_text_block(text: str) -> str:
    """A text drawing as a grey PNG data URI: every non-space character becomes a filled cell. A vision model
    reads a banner font from this where a text model reads nothing (measured: Super VL read a figlet word)."""
    cell_w, cell_h = ART_CELL
    lines = [line.rstrip() for line in text.splitlines()]
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines:
        return ""
    cols = min(max(len(line) for line in lines), 200)
    lines = lines[:80]
    width, height = cols * cell_w + 20, len(lines) * cell_h + 20
    rows = [bytearray([255] * width) for _ in range(height)]
    for r, line in enumerate(lines):
        for c, ch in enumerate(line[:cols]):
            if ch != " ":
                for y in range(10 + r * cell_h, 10 + (r + 1) * cell_h):
                    row = rows[y]
                    for x in range(10 + c * cell_w, 10 + (c + 1) * cell_w):
                        row[x] = 0

    def chunk(kind: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))

    raw = b"".join(b"\x00" + bytes(row) for row in rows)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii")


def strip_data_uris(text: str) -> str:
    """The text with every data: URI replaced by a short note, so a file pasted into a clue or a resource does
    not fill the prompt with base64 (its contents reach the models through ``findings`` instead)."""
    def note(match: re.Match[str]) -> str:
        head, _, payload = match.group(0).partition(";base64,")
        kind = head[5:].split(";")[0] or "file"
        return f"[attached file {kind}, {len(payload) * 3 // 4} bytes]"
    return _DATA_URI.sub(note, text)


def findings(texts: list[str], uris: list[str], log: Callable[[str], None] | None = None) -> list[str]:
    """Everything hidden in the texts and files of one challenge, as clue lines; logged when ``log`` is given."""
    out: list[str] = []
    for text in texts:
        out += decode_text(text)
        uris = uris + _DATA_URI.findall(text[:MAX_FILE * 2])   # a file pasted into a clue
    for uri in dict.fromkeys(uris):
        out += read_data_uri(uri)
    out = out[:MAX_FINDINGS]
    if log is not None:
        for line in out:
            log(f"hidden text: {line[:120]}")
    return out
