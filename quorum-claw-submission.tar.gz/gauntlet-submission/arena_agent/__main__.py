"""Start one heat:  python -m arena_agent   (reads ARENA_SERVER, ARENA_API_KEY, AGENT_ID from the environment)."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys

from arena_agent import sandbox
from arena_agent.agent import run
from arena_agent.config import from_env


def main() -> int:
    logging.basicConfig(level=logging.WARNING)
    for name in ("httpx", "httpx2", "mcp"):
        logging.getLogger(name).setLevel(logging.WARNING)
    # Not asyncio.run: on close it waits for every model call still running in a thread, and a racer that
    # lost the race can take up to the whole time limit to reply.
    loop = asyncio.new_event_loop()
    result = loop.run_until_complete(run(from_env()))
    print(json.dumps({"result": result}, ensure_ascii=False, default=str), flush=True)
    return 0 if result.get("status") == "submitted" else 1


def entry() -> None:
    """Play one heat and leave at once (also the packaged entrypoint, see agent_entry.py)."""
    code = main()
    sandbox.stop_all()   # a program still running for a racer that lost
    sys.stdout.flush()
    sys.stderr.flush()
    # The answer is in: leave now instead of waiting for a slower model's reply that is no longer needed.
    os._exit(code)


if __name__ == "__main__":
    entry()
