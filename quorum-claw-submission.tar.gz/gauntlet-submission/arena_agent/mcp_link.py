"""One MCP session over SSE with the arena key header, kept open for the whole heat.

Tool results are JSON objects: taken from structured content when present, else parsed from the first text
part. Problems come back inside the result as {"error": ..., "code": ...}, not as exceptions.
"""
from __future__ import annotations

import json
from typing import Any

import httpx2
from mcp import Client
from mcp.client.sse import sse_client

#: The SDK's SSE parser refuses any single event over 1 MiB and then closes the whole connection, which
#: would end a round whose challenge or tool result carries a file inline (an image is a few MiB as a
#: data URI). The parser is built by the SDK with its default, so the default itself is raised here.
SSE_EVENT_LIMIT = 64 * 1024 * 1024
httpx2.EventSource.__init__.__defaults__ = (SSE_EVENT_LIMIT,)   # type: ignore[attr-defined]


class McpLink:
    #: The stream is silent while the models think; a heat may last an hour, so no read timeout under that.
    def __init__(self, url: str, key: str, connect_timeout: float = 15.0, read_timeout: float = 3700.0) -> None:
        self.url = url
        self.key = key
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self._context: Any = None
        self.client: Any = None
        self.descriptions: dict[str, str] = {}             # tool name -> what the server says it does
        self.fields: dict[str, dict[str, str]] = {}        # tool name -> input field -> type or description
        self.schemas: dict[str, dict[str, Any]] = {}       # tool name -> its whole input schema (types, enums, required)
        self.called: set[str] = set()                       # tools the arena answered without an error

    async def __aenter__(self) -> "McpLink":
        self._context = Client(sse_client(self.url, headers={"X-Arena-API-Key": self.key},
                                          timeout=self.connect_timeout, sse_read_timeout=self.read_timeout))
        self.client = await self._context.__aenter__()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._context is not None:
            await self._context.__aexit__(*exc)

    async def tool_names(self) -> list[str]:
        return list(await self.tools())

    async def tools(self) -> dict[str, set[str]]:
        """Tool names with the input fields each one advertises (so optional fields are only sent if known)."""
        listing = await self.client.list_tools()
        out: dict[str, set[str]] = {}
        for tool in listing.tools:
            schema = getattr(tool, "input_schema", None) or getattr(tool, "inputSchema", None) or {}
            props = schema.get("properties") if isinstance(schema, dict) else None
            out[tool.name] = set(props) if isinstance(props, dict) else set()
            self.descriptions[tool.name] = str(getattr(tool, "description", None) or "")
            self.schemas[tool.name] = schema if isinstance(schema, dict) else {}
            self.fields[tool.name] = {
                name: str(spec.get("description") or spec.get("type") or "") if isinstance(spec, dict) else ""
                for name, spec in (props.items() if isinstance(props, dict) else [])}
        return out

    async def resources(self) -> list[dict[str, str]]:
        """The server's resources as {"uri", "name", "mime_type", "description"}: files, notes or data a server
        offers next to its tools. [] when it has none or does not support the call."""
        try:
            listing = await self.client.list_resources()
        except Exception:  # noqa: BLE001 - a server without resources answers with an error, not a list
            return []
        out = []
        for item in getattr(listing, "resources", None) or []:
            uri = str(getattr(item, "uri", "") or "")
            if uri:
                out.append({"uri": uri, "name": str(getattr(item, "name", "") or uri),
                            "mime_type": str(getattr(item, "mime_type", None) or getattr(item, "mimeType", None) or ""),
                            "description": str(getattr(item, "description", None) or "")})
        return out

    async def read_resource(self, uri: str) -> list[str]:
        """What one resource holds: text parts as they are, binary parts as data: URIs (decode.py reads those)."""
        result = await self.client.read_resource(uri)
        out = []
        for part in getattr(result, "contents", None) or []:
            text, blob = getattr(part, "text", None), getattr(part, "blob", None)
            mime = str(getattr(part, "mime_type", None) or getattr(part, "mimeType", None) or "application/octet-stream")
            if isinstance(text, str) and text.strip():
                out.append(text)
            elif isinstance(blob, str) and blob:
                out.append(f"data:{mime};base64,{blob}")
        return out

    async def call(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        reply = await self._call(name, args)
        if not reply.get("error"):
            self.called.add(name)   # counts for a challenge's required tools (see agent.call_required)
        return reply

    async def _call(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        result = await self.client.call_tool(name, args)
        if getattr(result, "is_error", False) or getattr(result, "isError", False):
            # the server's own failure text (a tool that raised, arguments it did not take) is not an answer
            text = next((getattr(p, "text", "") for p in getattr(result, "content", None) or []), "")
            return {"error": str(text or "the tool failed")[:300], "code": "tool_error"}
        structured = getattr(result, "structured_content", None)
        if isinstance(structured, dict):
            return structured
        for part in getattr(result, "content", None) or []:
            text = getattr(part, "text", None)
            if not text:
                continue
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                return {"text": text}
            return parsed if isinstance(parsed, dict) else {"result": parsed}
        return {}
