"""One heat from registration to submission, as fixed steps in code (no model call decides the steps).

1. Register (wait while the lobby is closed), read the usage scope for token attribution.
2. Connect MCP, discover tools, wait until the challenge opens, fetch it.
3. Collect clues and the time left: this also uses three distinct arena tools (full tool score). Unknown
   tools that take only the agent id (a hidden hint, say) are called blind at the same time, and what
   they say joins the clues; one that stays silent for a few seconds is left behind (see extra_tools).
   Encoded runs in the text and metadata or appended data in files handed over inline are decoded and
   join the clues too (decode.py), so the models read plain text instead of guessing at bytes. An unknown
   tool that needs an input (a decrypt tool wanting a key, say) is offered to one fast model once: it may
   ask for one call, whose result joins the clues (see ask_for_tool). Without such tools nothing changes.
4. Post a thought, then race the two best ranked models on the same question. A failed model is replaced
   by the next one. The first answer is saved as a draft at once; two agreeing answers are submitted at
   once; after a disagreement one more model breaks the tie. Next to the models, a program racer asks the
   best model for a Python program, runs it in the sandbox and answers with its output: it counts in the
   vote, and it is what answers puzzles that models cannot finish thinking about (search, constraints).
5. Without agreement, the best ranked model answer (the program's when no model answered) is submitted
   after a short patience window (an optional check of its form by another model is off, see
   CHECK_LONE_ANSWERS), and always by about 80 percent of the time limit.
6. Never "unknown" when it can be helped: if nothing answered, two models are asked (thinking off) for a
   quick best guess, given the cut-off thinking of the failed calls, inside the margin before the
   deadline. Only if that fails too, the fallback answer goes in.

Image challenges that want an edit go through image_flow.py; one that asks a question (a question field, or
a prompt ending in a question mark with no edit prompt) is answered in text: the hidden data in the image,
the arena's analyze tool and a vision model as one racer feed the same race (run_image_question). A challenge kind without a flow of its own (for example
arena.audio.get_challenge) is answered from its text fields through the same race (run_other); attached
media that cannot be read are named in the question. Every kind on offer is tried, the round's own first.
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from arena_agent import decode
from arena_agent import memory as puzzle_memory
from arena_agent.background import leave_quietly
from arena_agent.config import Config
from arena_agent.image_flow import BLANK_PNG, SUBMIT as IMAGE_SUBMIT, find_tool, run_image
from arena_agent.mcp_link import McpLink
from arena_agent.models import (CODE_PREFERENCE, DEMOTE, FALLBACK_ROSTER, ChatResult, ModelError, ModelPool, Proxy,
                                clean_answer, normalize, pick_first, rank_models, split_confidence)
from arena_agent.rest import ArenaError, Rest
from arena_agent.sandbox import CodeError, extract_code, run_code

#: The traditional reading of statements, where "All A are B" says that A exist. Puzzle keys use it; the
#: models read such statements the modern way and answered "No" where the key said "Yes". Measured on the
#: 8 practice syllogisms: 8 of 8 with this line against 6 of 8 without, in half the tokens.
TRADITIONAL_READING = (" Read the statements in the traditional way: the things a statement names exist. So "
                       "'All A are B' also tells you 'Some A are B', and with 'No B are C' it follows that "
                       "'Some A are not C'.")
SYSTEM = ("You are solving one challenge in a timed competition. Read the description, rules and clues. "
          "Think only as long as the problem needs. Reply with ONLY the final answer, in exactly the format the "
          "rules or the question ask for: no explanation, no prefix, no quotes, no code fences. Then add one "
          "last line of the form 'Confidence: 85' saying how sure you are, from 0 to 100.") + TRADITIONAL_READING
#: Submit the first answer at once when its model says it is at least this sure (0 to 100); None = off.
#: Measured on a 30-puzzle race: all 21 first answers that said 95 or more were right, the two wrong first
#: answers said 90, and no wrong answer said more than 95; 99 keeps a margin above that and still let 17 of
#: 23 first answers go in at about 1 to 2 s instead of waiting for a confirming one. The confidence line is
#: always removed before an answer is drafted or submitted.
EARLY_SUBMIT_CONFIDENCE: int | None = 99
#: The puzzle memory (memory.json next to this file, see memory.py): off unless ARENA_MEMORY=on, because
#: it cost answers in the practice race.
MEMORY = puzzle_memory.load()
CODE_SYSTEM = ("You solve one challenge in a timed competition by writing a program. Write a short Python 3 "
               "program that computes the answer exactly (search, brute force, simulation or direct "
               "calculation) and prints ONLY the final answer, in exactly the format the rules or the question "
               "ask for. The program must compute the answer itself: printing an answer you worked out yourself "
               "does not count. Standard library only (itertools, math, collections, functools, re, fractions); "
               "no input, no files, no network; it must finish within a few seconds. Make the first line of the "
               "program one comment: '# reads: text' when everything it needs is given as text, numbers or formulas, "
               "or '# reads: layout' when you had to transcribe a diagram, grid, drawing or arrangement of symbols "
               "into code. Reply with only the program in one ```python code block. If solving needs knowledge a "
               "program cannot compute (which words exist, what words mean, facts about the world), reply with "
               "exactly NO PROGRAM instead.")
NO_PROGRAM = "no program: the model says the puzzle needs knowledge a program cannot compute"
#: The program's own first comment (see CODE_SYSTEM). Programs that transcribe a layout carry the model's
#: misreading: on circuit diagrams 5 of 13 were right against the models' 14 of 23, on futoshiki grids 0 of 3;
#: programs over formal text were right 28 of 28 times on cryptarithms. A lone layout answer therefore waits
#: for a model's answer in the race; a lone text answer counts like a model's.
_READS = re.compile(r"^\s*#\s*reads\s*:\s*(text|layout)\b", re.IGNORECASE | re.MULTILINE)


def program_reads(program: str) -> str:
    """What the program's first comment says it read: "text", "layout", or "" when it does not say."""
    found = _READS.search(program[:400])
    return found.group(1).lower() if found else ""
#: Switches thinking off on models whose chat template supports it. In the program trial Nemotron 3 Super
#: with thinking on ran out of tokens before writing code on 8 of 9 hard puzzles; with this switch it wrote a
#: program in about 2 s. A model or proxy that rejects the field gets the request again without it.
NO_THINKING: dict[str, Any] = {"chat_template_kwargs": {"enable_thinking": False}}
CHECK_SYSTEM = ("You check an answer in a timed competition. Do not solve the problem yourself. Only check that "
                "the answer has the form the question asks for and breaks no rule you can see at a glance (for "
                "example a value outside the allowed range, a missing part, or a placeholder such as 0, _ or ? "
                "left in). Reply with VALID or INVALID first, then at most one short sentence.")
#: Off: in a 30-puzzle race the checker (Super, thinking off) re-solved instead of only looking at the form,
#: turned down three correct answers (once judging 19 as 18.33) and passed a wrong one; it only cost time.
CHECK_LONE_ANSWERS = False
CHECK_TOKENS = 256      # a verdict and one sentence
CHECK_MAX_S = 8.0       # a check with thinking off takes 1 to 2 s; it never holds an answer back longer
GUESS_SYSTEM = ("Time is almost up in a timed competition. Do not think step by step and do not explain. Reply "
                "with ONLY your best final answer, in exactly the format the rules or the question ask for.")
FALLBACK_ANSWER = "unknown"
CODE_PREFIX = "code:"   # label of the program racer in the race and in the run log
CODE_RUN_S = 10.0       # the program may run this long (a puzzle search finishes in well under a second)
REPAIR_MIN_S = 5.0      # a failed program gets one repair round only if this much call time is left
                        # (with thinking off a program came back in 1 to 3 s in the trial)
REPAIR_PROMPT = ("That program failed: {error}. Reply with the corrected program only, in one ```python code "
                 "block. It must compute the answer itself and print only the final answer.")
GUESS_TOKENS = 1024     # room for a short answer, also from a model that thinks briefly first
GUESS_MAX_S = 12.0      # the guess must fit into the margin before the deadline (18 s of a 90 s heat)
GUESS_MARGIN_S = 3.0    # kept free for the submission itself
GUESS_CONTEXT_CHARS = 6000   # how much of the cut-off thinking (its end) the guess gets to see
WAIT_CODES = ("locked", "waiting", "not_running", "lobby")
WRONG_MODALITY_CODES = ("not_image_challenge", "not_text_challenge")
#: The organizer's Practice says it in words, with no code: "This agent is assigned an image challenge; use
#: arena.image.get_challenge." All three image runs of 28 October crashed on it.
_ASSIGNED = re.compile(r"\bassigned an? ([a-z][a-z-]*) challenge\b|\buse arena\.[a-z.]*get_challenge\b", re.I)
#: Check for GO once a second: GO starts everyone's clock, so a slower check costs speed score, and one small
#: tool call a second is light on the arena.
LOBBY_POLL_S = 1.0
MAX_CLUES = 10
#: Output speed assumed for the fast racer, tokens per second. Measured through the practice proxy: 285 to
#: 370 in a 12-call trial, about 450 in one race, 240 to 300 the evening before the event. A model listed
#: here gets as many output tokens as it can write before the submit deadline at this speed, up to
#: TOKENS_CEILING and never under the configured limit. The speed is set low on purpose: at 280 a 19k call
#: timed out at the deadline on every circuit heat of a slow evening, which costs the speed points and the
#: partial thinking the final guess would use; a cut-off ends early and keeps that thinking. Measured on 16
#: hard puzzles: DeepSeek solved 3 of 8 futoshiki grids at 8k tokens, 6 at 16k (none needing more than 12.8k)
#: and 8 of 8 at 24k; circuits stayed unsolved at every cap. Slow thinkers (Super at about 180 tokens a
#: second) keep the configured limit: 8k already takes them 45 s.
TOKENS_PER_S = {"deepseek": 200.0}
TOKENS_CEILING = 24576
TOKENS_MARGIN_S = 4.0   # of the time left, kept free: the reply still has to travel back
TOKENS_DEFAULT_PER_S = 100.0   # a model with no measured speed, on a short round only. Measured medians from the run
#: records (tokens out over call time): Super 188 a second on two healthy nights (n=20), GLM 90 (n=3), DeepSeek 221
#: to 268 (n=68). The low side on purpose: a low rate cuts a model off with its thinking kept for the final guess;
#: a high rate lets it time out with nothing.
TOKENS_MIN = 1024              # never less: a short reply with a little thinking
SHORT_LEFT_S = 40.0            # an unmeasured model keeps its configured limit down to this much time left at the race
#: start (a 60 s round starts with 45 to 47 s, so it stays unchanged even after 7 s of pre-race steps); below it, the
#: 8k floor cannot finish before the deadline at any measured speed under 230 a second, so what fits in the time is
#: the cap. A measured model follows the time always: no floor, so no cliff at the boundary.
RACE_WIDTH = 2          # models asked at the same time
#: When every model failed on overload or network errors (a proxy under the load of many agents) and nothing is
#: running, the race waits and asks them again instead of giving up with minutes left. A refused call costs no
#: tokens; a model cut off at the token cap is never asked again.
RETRY_WAIT_S = 3.0
RETRY_LIMIT = 2         # times each model is asked again at most
RETRY_MIN_LEFT_S = 10.0   # no retry closer than this to the submit deadline: the quick guess needs that margin
RACE_MAX_ANSWERS = 3    # two racers plus at most one tie-breaker
PATIENCE_MIN_S = 5.0    # after the first answer, wait at least this long for a confirming one
PROGRAM_PATIENCE_S = 12.0   # ... and at least this long when the first answer is a program's over text: four
#: breadth-set losses were a program answering in 1 to 6 s, the 5 s window closing, and the models still thinking
READ_TOKENS = 1024      # a racer that only has to read a rendered drawing: thinking off, a short reply
READ_NOTE = ("\n\nThe picture is the drawing above as block letters. It may spell a made-up word: read it letter "
             "by letter, keep doubled letters, and answer with exactly the letters you see.")   # ASSERTA was read
#: as ASSERTION and ASERTA: the readers complete a word they know and drop a doubled letter
PATIENCE_FACTOR = 1.5   # or this many times as long as the first answer took, whichever is longer


def log(message: str) -> None:
    print(f"{time.strftime('%H:%M:%S')} [agent] {message}", flush=True)


def clue_text(item: Any) -> str:
    if isinstance(item, dict):
        return str(item.get("text") or item.get("content") or "")
    return str(item or "")


def build_messages(challenge: dict[str, Any], clues: list[str], system: str = SYSTEM) -> list[dict[str, str]]:
    parts = [f"Challenge type: {challenge.get('challenge_type') or 'unknown'}", "", "Description:",
             decode.trim_text(decode.strip_data_uris(str(challenge.get("description") or "")))]
    rules = decode.strip_data_uris(str(challenge.get("rules") or "")).strip()
    if rules:
        parts += ["", "Rules:", rules]
    clues = [decode.strip_data_uris(c) for c in clues if c.strip()]
    if clues:
        parts += ["", "Clues:"] + [f"- {c}" for c in clues]
    return [{"role": "system", "content": system}, {"role": "user", "content": "\n".join(parts)}]


def submit_deadline(now: float, time_left_s: float, max_time_s: float, cfg: Config) -> float:
    """Monotonic time by which to submit: the deadline minus the larger of the fixed margin and the
    unused share of the time limit (20 percent by default)."""
    return now + time_left_s - max(cfg.min_margin_s, (1.0 - cfg.submit_fraction) * max_time_s)


class WrongModality(RuntimeError):
    """The arena says the running heat is another kind of challenge (text, image, audio ...)."""


async def wait_for_challenge(mcp: McpLink, agent_id: str, timeout_s: float,
                             tool: str = "arena.get_challenge") -> dict[str, Any]:
    deadline = time.monotonic() + timeout_s
    told = False
    while True:
        data = await mcp.call(tool, {"agent_id": agent_id})
        error = data.get("error")
        if not error:
            return data
        code = str(data.get("code") or "").lower()
        text = str(error).lower()
        if code in WRONG_MODALITY_CODES or (code.startswith("not_") and code.endswith("_challenge")) \
                or _ASSIGNED.search(text):
            raise WrongModality(f"{tool}: {error} ({code})")
        waiting = code in WAIT_CODES or "locked" in text or "waiting" in text
        if not waiting or time.monotonic() >= deadline:
            raise RuntimeError(f"{tool}: {error} ({code or 'no code'})")
        if not told:   # say it once, then wait quietly
            log(f"challenge not open yet ({code or text[:60]}); checking every {LOBBY_POLL_S:.0f} s until GO")
            told = True
        await asyncio.sleep(LOBBY_POLL_S)


@dataclass
class RaceOutcome:
    answer: str = ""
    model: str | None = None
    agreed: bool = False
    guessed: bool = False   # the answer is a quick guess after nothing else answered in time
    fallback: str = ""      # the best answer the checker rejected: used only if nothing better comes
    fallback_model: str | None = None
    answers: list[tuple[str, str]] = field(default_factory=list)   # (model, cleaned answer), arrival order
    prompt_tokens: int = 0
    completion_tokens: int = 0
    model_ms: float = 0.0
    calls: list[dict[str, Any]] = field(default_factory=list)   # one per model call, start order, for the run log


def tokens_for(model: str, max_tokens: int, left_s: float) -> int:
    """The output token limit for one racer call with ``left_s`` seconds until the submit deadline: the
    configured limit, or for a model with a known speed what it can write in that time (see TOKENS_PER_S).
    A measured model follows the time always (no floor); an unmeasured one keeps the configured limit until
    the round is short (see SHORT_LEFT_S), then gets what fits at TOKENS_DEFAULT_PER_S."""
    rate = next((r for key, r in TOKENS_PER_S.items() if key in model.lower()), None)
    if rate is None:
        if left_s >= SHORT_LEFT_S:
            return max_tokens
        return max(TOKENS_MIN, min(max_tokens, int(TOKENS_DEFAULT_PER_S * (left_s - TOKENS_MARGIN_S))))
    return max(TOKENS_MIN, min(TOKENS_CEILING, int(rate * (left_s - TOKENS_MARGIN_S))))


_REFUSAL = re.compile(r"^(i['\u2019]m sorry|i am sorry|sorry,|i cannot|i can['\u2019]t|unable to|as an ai)", re.I)


def is_refusal(answer: str) -> bool:
    """An apology or a refusal in place of an answer (seen from a final guess on an unsolved puzzle)."""
    return bool(_REFUSAL.match(answer.strip()))


def is_program(label: str) -> bool:
    return label.startswith(CODE_PREFIX)


def chat_without_thinking(proxy: Proxy, model: str, messages: list[dict[str, str]], max_tokens: int,
                          timeout: float) -> ChatResult:
    """One chat call with thinking switched off; asked again without the switch if it is refused (HTTP 400)."""
    t0 = time.perf_counter()
    try:
        return proxy.chat(model, messages, max_tokens, timeout, NO_THINKING)
    except ModelError as exc:
        if exc.kind != "http_400":
            raise
        log(f"{model}: the thinking switch was refused; asking again without it")
        return proxy.chat(model, messages, max_tokens, timeout - (time.perf_counter() - t0))


async def check_answer(proxy: Proxy, model: str, messages: list[dict[str, str]], answer: str,
                       timeout: float) -> tuple[str, str]:
    """('valid' | 'invalid' | 'unsure', note): a quick look by ``model`` (thinking off) at the form of
    ``answer``. Anything but a clear INVALID lets the answer through."""
    check_messages = [{"role": "system", "content": CHECK_SYSTEM},
                      {"role": "user", "content": f"{messages[-1]['content']}\n\nAnswer to check:\n{answer}"}]
    try:
        reply = await asyncio.to_thread(chat_without_thinking, proxy, model, check_messages, CHECK_TOKENS, timeout)
    except Exception as exc:  # noqa: BLE001 - a failed check never blocks an answer
        return "unsure", str(exc)[:200]
    text = clean_answer(reply.content)
    head = text.upper()
    if head.startswith("INVALID"):
        return "invalid", text[:200]
    return ("valid" if head.startswith("VALID") else "unsure"), text[:200]


def _try_program(reply: ChatResult) -> tuple[str, str | None, str | None]:
    """(program, output, error) for one model reply; exactly one of output and error is set."""
    program = extract_code(reply.content)
    if not program:
        if clean_answer(reply.content).strip().upper().startswith("NO PROGRAM"):
            return "", None, NO_PROGRAM   # word ladders, jumbles: a program answered wrongly alone twice
        return "", None, "the reply had no ```python code block"
    try:
        return program, run_code(program, CODE_RUN_S), None
    except CodeError as exc:
        return program, None, str(exc)[:300]


async def solve_with_code(proxy: Proxy, model: str, messages: list[dict[str, str]], max_tokens: int,
                          timeout: float) -> ChatResult:
    """The program racer: ask ``model`` (thinking off) for a program, run it in the sandbox and answer with
    what it prints. A program that fails (no code, syntax error, crash, refused, prints nothing) gets one
    repair round with the error, if enough time is left."""
    label = CODE_PREFIX + model
    t0 = time.perf_counter()
    reply = await asyncio.to_thread(chat_without_thinking, proxy, model, messages, max_tokens, timeout)
    program, output, error = await asyncio.to_thread(_try_program, reply)
    usage = dict(reply.usage)
    left = timeout - (time.perf_counter() - t0)
    if error == NO_PROGRAM:
        log(f"{label}: {error}")
        raise ModelError(label, "program_failed", error, reply=reply.content, reasoning=reply.reasoning)
    if error and left >= REPAIR_MIN_S:
        log(f"{label}: program failed ({error[:80]}); one repair round")
        repair = messages + [{"role": "assistant", "content": reply.content},
                             {"role": "user", "content": REPAIR_PROMPT.format(error=error)}]
        first_error = error
        reply = await asyncio.to_thread(chat_without_thinking, proxy, model, repair, max_tokens, left)
        program, output, error = await asyncio.to_thread(_try_program, reply)
        usage = {k: int(usage.get(k) or 0) + int(reply.usage.get(k) or 0)
                 for k in ("prompt_tokens", "completion_tokens", "total_tokens")}
        if error:
            error = f"{first_error}; after the repair: {error}"
    if error:
        raise ModelError(label, "program_failed", error, reply=program or reply.content, reasoning=reply.reasoning)
    return ChatResult(label, output or "", usage, (time.perf_counter() - t0) * 1000, reply.finish_reason,
                      reply.reasoning, program, program_reads(program))


def media_part(uri: str) -> dict[str, Any]:
    """The OpenAI content part for a data: URI by its kind: image_url, input_audio (base64 and format) or
    video_url. Whether a model takes audio or video parts is the proxy's business; a refusal is one failed call."""
    kind = media_kind(uri)
    if kind == "audio":
        head, _, payload = uri.partition(";base64,")
        fmt = head.split("/")[-1].lower()
        fmt = {"mpeg": "mp3", "x-wav": "wav", "wave": "wav", "x-flac": "flac"}.get(fmt, fmt)
        return {"type": "input_audio", "input_audio": {"data": payload, "format": fmt}}
    if kind == "video":
        return {"type": "video_url", "video_url": {"url": uri}}
    return {"type": "image_url", "image_url": {"url": uri}}


def with_image(messages: list[dict[str, Any]], image_uri: str) -> list[dict[str, Any]]:
    """The same messages with the file attached to the user turn, in the OpenAI content-parts form."""
    out = [dict(m) for m in messages]
    for m in reversed(out):
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            m["content"] = [{"type": "text", "text": m["content"]}, media_part(image_uri)]
            break
    return out


with_media = with_image

_READ_PREFIX = re.compile(r"^(the (word|text|letters|banner|picture|image)( says| is| reads| shows| spells)?"
                          r"|it (says|reads|spells)|answer)\b\s*[:\-]?\s*", re.I)
_SPELLED = re.compile(r"^(?:[A-Za-z0-9][ \-.]){2,}[A-Za-z0-9]$")   # letters spelled out: R E S, A-B-C


def tidy_reading(answer: str) -> str:
    """A reader's word as the answer: a leading 'The word is' dropped, letters spelled out with spaces or
    dashes joined ('R E S' -> 'RES'), quotes and a final full stop removed. Seen from the third reader:
    'The word is: ASCENT' and 'R E S' (the right reading, which no other vote could match)."""
    text = answer.strip(" \"'`.")
    text = _READ_PREFIX.sub("", text, count=1).strip(" \"'`.")
    if _SPELLED.match(text):
        text = re.sub(r"[ \-.]", "", text)
    return text or answer


def with_note(messages: list[dict[str, Any]], note: str) -> list[dict[str, Any]]:
    """The same messages with ``note`` appended to the last user turn's text."""
    out = [dict(m) for m in messages]
    for m in reversed(out):
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            m["content"] = m["content"] + note
            break
    return out


async def race(proxy: Proxy, pool: ModelPool, messages: list[dict[str, str]], max_tokens: int, submit_by: float,
               on_first: Callable[[str, str], Awaitable[None]] | None = None,
               code_messages: list[dict[str, str]] | None = None, check: bool = True,
               width: int = RACE_WIDTH, image_uri: str = "", vision: frozenset[str] | set[str] = frozenset(),
               trust_text_programs: bool = True, reading: bool = False) -> RaceOutcome:
    """Ask the best ranked models at once and stop as soon as two answers agree.

    Failed models are marked down and replaced by the next one; a model cut off at the token cap is not
    (the puzzle was too long for it, not the model broken: in 16 hard practice heats no replacement ever
    answered before the deadline, at 8k wasted tokens each), its thinking feeds the final guess instead.
    With ``code_messages`` the best model also
    writes a program (the program racer); its output votes like an answer but does not take a model's
    place. Alone, a program that transcribed a layout (its first line says ``# reads: layout``), or does not
    say what it read, does not start the patience window: such programs carry the model's misreading (see
    program_reads), so the race waits for a model's answer or the submit time. A lone program over text
    (``# reads: text``) counts like a model's answer. After the first answer the race waits only a patience
    window for a confirming answer; after a
    disagreement one tie-breaker gets a little longer. Without agreement the best ranked model's answer
    is chosen (the program's only when no model answered) and, with ``check``, another model looks at its
    form first: a clear INVALID turns it down and the race goes on for other answers until the submit
    time (the rejected answer stays as ``fallback``). Calls still running when the race ends are not
    waited for (their tokens still count at the proxy)."""
    out = RaceOutcome()
    rank = {m: i for i, m in enumerate(pool.ranked)}
    queue = list(pool.available())
    pending: dict[asyncio.Task[Any], str] = {}
    call_of: dict[asyncio.Task[Any], dict[str, Any]] = {}
    start = time.monotonic()
    wait_until = submit_by
    first_latency: float | None = None

    def begin(label: str, job: Awaitable[Any]) -> None:
        task = asyncio.ensure_future(job)
        pending[task] = label
        call_of[task] = {"model": label, "started_s": round(time.monotonic() - start, 2),
                         "outcome": "no reply before submit"}
        out.calls.append(call_of[task])

    def models_in(labels: Any) -> int:
        return sum(not is_program(m) for m in labels)

    cut_off: set[str] = set()   # racers that ran out of tokens; they keep their slot, no replacement

    def launch(limit: int) -> None:
        """Start models until model answers, running model calls and cut-off racers reach ``limit``."""
        while queue and models_in(m for m, _ in out.answers) + models_in(pending.values()) + len(cut_off) < limit:
            left = submit_by - time.monotonic() - 1.0
            if left < 3.0:
                queue.clear()
                return
            model = queue.pop(0)
            if image_uri and model in vision and reading:
                # A banner to read, not a puzzle to reason about: thinking off read a word in one shot in the
                # probe; thinking on hit the token cap after 19 s and never answered. A puzzle drawn in text (a
                # board, a maze) keeps thinking on: the vision model then reasons from the text like the others.
                begin(model, asyncio.to_thread(chat_without_thinking, proxy, model,
                                               with_image(with_note(messages, READ_NOTE), image_uri), READ_TOKENS, left))
                continue
            asked = with_image(messages, image_uri) if image_uri and model in vision else messages
            begin(model, asyncio.to_thread(proxy.chat, model, asked, tokens_for(model, max_tokens, left), left))

    def best_of(labels: list[str]) -> str:
        """Best ranked model; the program is not ranked, so it wins only alone."""
        return min(labels, key=lambda m: rank.get(m, len(rank)))

    def checker_for(label: str) -> str | None:
        """Another model than the one that wrote the answer, an idle one if possible."""
        author = label[len(CODE_PREFIX):] if is_program(label) else label
        idle = [m for m in pool.available() if m != author and m not in pending.values()]
        return (idle or [m for m in pool.ranked if m != author] or [None])[0]

    coder = pick_first(pool.available(), CODE_PREFERENCE)
    launch(width)
    code_left = submit_by - time.monotonic() - CODE_RUN_S - 1.0
    if code_messages is not None and coder and code_left >= 5.0:
        begin(CODE_PREFIX + coder, solve_with_code(proxy, coder, code_messages, max_tokens, code_left))
    log(f"race: {', '.join(pending.values()) or 'no model available'}")
    rejected: set[str] = set()   # racers whose answer the checker turned down
    failed: list[str] = []       # racers that failed on overload, errors or timeouts, in order (see RETRY_WAIT_S)
    retried: dict[str, int] = {}
    while True:
        extra = models_in(rejected)   # a rejected model answer does not count as a racer's answer
        while pending:
            timeout = wait_until - time.monotonic()
            if timeout <= 0:
                log("race: patience window over")
                break
            done, _ = await asyncio.wait(list(pending), timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
            if not done:
                log("race: patience window over")
                break
            for task in done:
                model = pending.pop(task)
                call = call_of[task]
                call["ended_s"] = round(time.monotonic() - start, 2)
                try:
                    reply = task.result()
                except Exception as exc:  # noqa: BLE001 - ModelError or anything else: replace this model
                    call.update(outcome="failed", error=str(exc)[:300], reply=getattr(exc, "reply", ""),
                                reasoning=getattr(exc, "reasoning", ""))
                    if is_program(model):
                        log(f"program racer failed: {exc}")
                    elif isinstance(exc, ModelError) and exc.kind == "cut_off":
                        cut_off.add(model)
                        log(f"{model} ran out of tokens; no replacement, its thinking feeds the final guess")
                    else:
                        pool.mark_down(model)
                        failed.append(model)
                        log(f"model failed: {exc}; the next one joins")
                    continue
                cleaned, confidence = split_confidence(clean_answer(reply.content))
                if reading and model in vision and cleaned:
                    cleaned = tidy_reading(cleaned)
                if not cleaned:   # only a confidence line came back: no answer
                    call.update(outcome="failed", error="only a confidence line", reply=reply.content)
                    continue
                if is_refusal(cleaned):
                    call.update(outcome="failed", error="a refusal, not an answer", reply=reply.content)
                    log(f"{model} refused instead of answering; not counted")
                    continue
                call.update(outcome="answered", answer=cleaned, confidence=confidence, reply=reply.content,
                            reasoning=reply.reasoning, finish_reason=reply.finish_reason,
                            completion_tokens=reply.usage.get("completion_tokens"))
                if reply.program:
                    call["program"], call["reads"] = reply.program, reply.reads
                out.answers.append((model, cleaned))
                out.prompt_tokens += int(reply.usage.get("prompt_tokens") or 0)
                out.completion_tokens += int(reply.usage.get("completion_tokens") or 0)
                out.model_ms = max(out.model_ms, reply.ms)
                log(f"{model} answered in {reply.ms / 1000:.1f} s ({reply.usage.get('completion_tokens')} tokens out)")
                now = time.monotonic()
                if (first_latency is None and is_program(model) and (reply.reads != "text" or not trust_text_programs)
                        and not models_in(m for m, _ in out.answers)):
                    if on_first is not None:   # drafted all the same: it is the answer if no model makes it
                        await on_first(model, cleaned)
                    read = "transcribed a layout" if reply.reads else "does not say what it read"
                    log(f"race: the program answered first and {read}; waiting for a model's answer before trusting it")
                elif first_latency is None:
                    first_latency = now - start
                    floor = PROGRAM_PATIENCE_S if is_program(model) else PATIENCE_MIN_S
                    wait_until = min(submit_by, now + max(floor, PATIENCE_FACTOR * first_latency))
                    if on_first is not None:
                        await on_first(model, cleaned)
                    dissent = [m for m, a in out.answers if m != model and normalize(a) != normalize(cleaned)]
                    reader = reading and model in vision   # a banner reading: sure and wrong twice (ASERTA, SEO)
                    if (EARLY_SUBMIT_CONFIDENCE is not None and confidence is not None
                            and confidence >= EARLY_SUBMIT_CONFIDENCE and not is_program(model) and not reader
                            and not dissent):
                        wait_until = now   # sure enough: no waiting for a confirming answer
                        log(f"race: {model} is {confidence} percent sure; submitting without waiting")
                    elif reader and confidence is not None and confidence >= (EARLY_SUBMIT_CONFIDENCE or 101):
                        log(f"race: {model} read the drawing and is {confidence} percent sure; waiting for a second reading")
                    elif dissent and confidence is not None and confidence >= (EARLY_SUBMIT_CONFIDENCE or 101):
                        # Seen three times on the breadth set: a 100 percent sure answer against a program's
                        # answer, the program right once. The disagreement is worth the patience window.
                        log(f"race: {model} is {confidence} percent sure but {', '.join(dissent)} disagrees; waiting")
                elif rejected:
                    wait_until = min(submit_by, now + PATIENCE_MIN_S)   # a new answer after a rejection
                key = normalize(cleaned)
                agreeing = [m for m, a in out.answers if normalize(a) == key]
                if len(agreeing) >= 2:
                    out.model = best_of(agreeing)
                    out.answer = next(a for m, a in out.answers if m == out.model)
                    out.agreed = True
                    log(f"race: {len(agreeing)} models agree")
                    leave_quietly(call_of)
                    return out
            if not models_in(pending.values()) and models_in(m for m, _ in out.answers) >= width + extra:
                launch(max(RACE_MAX_ANSWERS, width + 1) + extra)   # every model racer answered and they disagree: a tie-breaker
                if models_in(pending.values()) and first_latency is not None:
                    log(f"race: no agreement yet; tie-breaker {', '.join(pending.values())}")
                    wait_until = min(submit_by, time.monotonic() + max(PATIENCE_MIN_S, 2.5 * first_latency))
            else:
                launch(width + extra)              # replace racers that failed

        if not out.answers and not pending and not queue:
            again = [m for m in dict.fromkeys(failed) if retried.get(m, 0) < RETRY_LIMIT]
            wait = min(RETRY_WAIT_S, submit_by - time.monotonic() - RETRY_MIN_LEFT_S)
            if again and wait > 0:
                log(f"race: every model failed; asking {', '.join(again)} again in {wait:.0f} s")
                await asyncio.sleep(wait)
                for m in again:
                    retried[m] = retried.get(m, 0) + 1
                queue.extend(again)
                launch(width + extra)
                if pending:
                    continue

        # No agreement: the best answer not yet turned down gets a quick check by another model.
        candidates = [m for m, _ in out.answers if m not in rejected]
        if not candidates:
            break
        pick = best_of(candidates)
        answer = next(a for m, a in out.answers if m == pick)
        checker = checker_for(pick) if check else None
        left = submit_by - time.monotonic() - 1.0
        if checker is None or left < 2.0:
            out.model, out.answer = pick, answer
            log(f"race: no agreement; using {pick}" + ("" if not check else " (no time or model for a check)"))
            break
        verdict, note = await check_answer(proxy, checker, messages, answer, min(CHECK_MAX_S, left))
        out.calls.append({"model": checker, "check_of": pick, "outcome": f"check {verdict}", "note": note})
        if verdict != "invalid":
            out.model, out.answer = pick, answer
            log(f"race: no agreement; {pick}'s answer passed the check by {checker} ({verdict})")
            break
        log(f"race: {checker} rejected {pick}'s answer ({note[:80]}); waiting for other answers")
        rejected.add(pick)
        if not out.fallback:
            out.fallback, out.fallback_model = answer, pick
        wait_until = submit_by
        launch(width + models_in(rejected))
        if not pending:
            break
    leave_quietly(call_of)
    return out


def cut_off_thinking(calls: list[dict[str, Any]]) -> str:
    """The longest thinking of the calls that ended without an answer (a model that ran out of tokens),
    with its think tags removed; '' if there is none."""
    texts = [str(c.get("reasoning") or "") or ("" if is_program(str(c.get("model"))) else str(c.get("reply") or ""))
             for c in calls if c.get("outcome") == "failed"]
    return re.sub(r"</?think>", "", max(texts, key=len, default=""), flags=re.I).strip()


def broken_models(calls: list[dict[str, Any]]) -> set[str]:
    """Models whose call failed for another reason than running out of tokens (overloaded, error, timeout)."""
    return {str(c.get("model")) for c in calls
            if c.get("outcome") == "failed" and not any(k in str(c.get("error")) for k in ("cut_off", "empty_answer"))}


async def quick_guess(proxy: Proxy, pool: ModelPool, messages: list[dict[str, str]], out: RaceOutcome,
                      deadline: float) -> None:
    """Nothing answered in time: ask the two best ranked models that are not broken for a quick best guess,
    with thinking off and the end of the cut-off thinking as a head start, inside the margin before the
    deadline. (Running out of tokens is no reason to skip a model here: with thinking off it answers.)
    The first usable reply goes into ``out``; if none comes, ``out`` stays empty."""
    left = min(GUESS_MAX_S, deadline - time.monotonic() - GUESS_MARGIN_S)
    broken = broken_models(out.calls)
    models = [m for m in pool.ranked if m not in broken][:2] or pool.ranked[:2]
    if left < 2.0 or not models:
        return
    user = messages[-1]["content"]
    partial = cut_off_thinking(out.calls)
    if partial:
        user += "\n\nYour unfinished thinking so far (cut off):\n" + partial[-GUESS_CONTEXT_CHARS:]
    guess_messages = [{"role": "system", "content": GUESS_SYSTEM}, {"role": "user", "content": user}]
    log(f"nothing answered; asking {' and '.join(models)} for a quick guess ({left:.0f} s)")
    start = time.monotonic()
    tasks: dict[asyncio.Task[Any], dict[str, Any]] = {}
    for model in models:
        task = asyncio.ensure_future(asyncio.to_thread(chat_without_thinking, proxy, model, guess_messages,
                                                       GUESS_TOKENS, left))
        tasks[task] = {"model": model, "guess": True, "started_s": 0.0, "outcome": "no reply before submit"}
        out.calls.append(tasks[task])
    while tasks:
        done, _ = await asyncio.wait(list(tasks), timeout=max(0.0, start + left - time.monotonic()),
                                     return_when=asyncio.FIRST_COMPLETED)
        if not done:
            break
        for task in done:
            call = tasks.pop(task)
            call["ended_s"] = round(time.monotonic() - start, 2)
            try:
                reply = task.result()
            except Exception as exc:  # noqa: BLE001 - an empty or failed guess: wait for the other one
                call.update(outcome="failed", error=str(exc)[:300])
                continue
            cleaned = clean_answer(reply.content)
            if is_refusal(cleaned):
                call.update(outcome="failed", error="a refusal, not an answer", reply=reply.content)
                continue
            call.update(outcome="answered", answer=cleaned, reply=reply.content, reasoning=reply.reasoning)
            out.prompt_tokens += int(reply.usage.get("prompt_tokens") or 0)
            out.completion_tokens += int(reply.usage.get("completion_tokens") or 0)
            if cleaned and not out.answer:
                out.answer, out.model, out.guessed = cleaned, call["model"], True
                log(f"quick guess by {call['model']}")
                leave_quietly(tasks)
                return
    leave_quietly(tasks)


async def _safe(label: str, fn: Any, *args: Any) -> Any:
    try:
        return await asyncio.to_thread(fn, *args)
    except (ArenaError, OSError) as exc:
        log(f"{label} failed: {exc}")
        return None


def text_pool(rows: list[dict[str, Any]], cfg: Config) -> ModelPool:
    """The ranked text models of the roster, as the race builds them."""
    roster = [str(r["id"]) for r in rows] or list(FALLBACK_ROSTER)
    return ModelPool(rank_models(roster) or list(FALLBACK_ROSTER), cooldown_s=cfg.model_cooldown_s)


async def answer_and_submit(cfg: Config, rest: Rest, proxy: Proxy, rows: list[dict[str, Any]],
                            challenge: dict[str, Any], clues: list[str], submit_by: float, deadline: float,
                            submit_type: str, result: dict[str, Any], prefer: tuple[str, ...] = (),
                            image_uri: str = "", vision: frozenset[str] | set[str] = frozenset(),
                            rendered: bool = False, reading: bool = False) -> None:
    """Thought, race, quick guess and submission through the web API, for a challenge answered in text.
    ``prefer`` puts models first in the ranking (a vision model for an image question); ``image_uri`` is
    attached to the prompt of the models in ``vision``, and no program is written for an image unless the
    image is only a ``rendered`` drawing of the text (the program still has the text). ``reading`` says that
    drawing is a banner to read: the vision racers answer without thinking and vote (see drawing_order)."""
    ctype = str(challenge.get("challenge_type") or submit_type)
    roster = [str(r["id"]) for r in rows] or list(FALLBACK_ROSTER)
    pool = ModelPool(rank_models(roster) or list(FALLBACK_ROSTER), cooldown_s=cfg.model_cooldown_s)
    if prefer:
        pool.ranked = [m for m in prefer if m in roster] + [m for m in pool.ranked if m not in prefer]
    width = RACE_WIDTH
    hint = puzzle_memory.advise("\n".join([str(challenge.get("description") or "")] + clues), pool.ranked, MEMORY,
                                keep_last=DEMOTE)
    if hint is not None:   # close practiced puzzles: race the models that got those right, wider when hard
        pool.ranked = hint.ranked
        width = RACE_WIDTH + (1 if hint.hard else 0)
        result["memory"] = {"matches": hint.matches, "similarity": hint.similarity, "hard": hint.hard,
                            "first": hint.ranked[:width]}
        log(f"memory: {hint.matches} similar practiced puzzle(s) (closest {hint.similarity}); "
            f"{'hard, ' if hint.hard else ''}racing {', '.join(hint.ranked[:width])}")
    log(f"models in order: {', '.join(pool.ranked[:5])}")
    racers = pool.available()[:width]
    coder = pick_first(pool.available(), CODE_PREFERENCE)
    await _safe("thought", rest.thought, cfg.agent_id,
                f"{ctype}: {len(clues)} clue(s); asking {' and '.join(racers) or 'no model'} at once, "
                f"and {coder or 'no model'} for a program")

    async def save_first(model: str, answer: str) -> None:
        await _safe("draft", rest.draft, cfg.agent_id, answer, f"first answer, by {model}")

    messages = build_messages(challenge, clues)
    decoded = any(c.startswith("Decoded from") for c in clues)   # the decoder did the work: the models have it
    outcome = await race(proxy, pool, messages, cfg.max_tokens, submit_by, save_first,
                         code_messages=None if image_uri and not rendered else build_messages(challenge, clues, CODE_SYSTEM),
                         check=CHECK_LONE_ANSWERS, width=width, image_uri=image_uri, vision=vision,
                         trust_text_programs=not decoded, reading=reading)
    if not outcome.answer:
        await quick_guess(proxy, pool, messages, outcome, deadline)
    if not outcome.answer and outcome.fallback:   # a rejected answer still beats "unknown"
        outcome.answer, outcome.model = outcome.fallback, outcome.fallback_model
    final = outcome.answer or FALLBACK_ANSWER
    metrics = {"model_name": outcome.model or "none", "prompt_tokens": outcome.prompt_tokens,
               "completion_tokens": outcome.completion_tokens,
               "total_tokens": outcome.prompt_tokens + outcome.completion_tokens,
               "total_time_ms": round(outcome.model_ms)}
    receipt = await asyncio.to_thread(rest.submit, cfg.agent_id, final, metrics, submit_type)
    log(f"submitted ({receipt.get('status')}); score {receipt.get('score')}")
    result.update(status="submitted", model=outcome.model, agreed=outcome.agreed, guessed=outcome.guessed,
                  answer=final, answers=outcome.answers, receipt=receipt, calls=outcome.calls)


async def clues_and_time(mcp: McpLink, cfg: Config, clues: list[str], max_time: float, submit_by: float,
                         deadline: float) -> tuple[list[str], float, float]:
    """The clue list, each clue's text and the time left, through the three arena tools every round should use
    (the tool axis counts distinct tools, capped at 3). Clues are optional: a failure is logged, not fatal."""
    try:
        listed = await mcp.call("arena.clues.list", {"agent_id": cfg.agent_id})
        for clue_id in (listed.get("clue_ids") or [])[:MAX_CLUES]:
            if time.monotonic() > submit_by - 10:
                break
            got = await mcp.call("arena.clues.get", {"clue_id": clue_id, "agent_id": cfg.agent_id})
            if got.get("text"):
                clues.append(str(got["text"]))
        timing = await mcp.call("arena.time_remaining", {"agent_id": cfg.agent_id})
        if isinstance(timing.get("time_remaining_s"), (int, float)):
            submit_by = min(submit_by, submit_deadline(time.monotonic(), float(timing["time_remaining_s"]),
                                                       max_time, cfg))
            deadline = min(deadline, time.monotonic() + float(timing["time_remaining_s"]))
    except Exception as exc:  # noqa: BLE001 - clues are optional; the answer is not
        log(f"clue or time tools failed: {exc}")
    return clues, submit_by, deadline


async def run_text(cfg: Config, rest: Rest, mcp: McpLink, proxy: Proxy, rows: list[dict[str, Any]],
                   tools: dict[str, set[str]], result: dict[str, Any]) -> None:
    """The text challenge: fetch, clues, time and the extra tools, then answer_and_submit. Fills ``result``."""
    challenge = await wait_for_challenge(mcp, cfg.agent_id, cfg.registration_timeout_s)
    extras = start_extras(mcp, cfg.agent_id, tools)   # they answer while the clues are fetched
    result["modality"] = "text"
    max_time = float(challenge.get("max_time_s") or 60.0)
    time_left = seconds(challenge.get("time_remaining_s"), max_time)
    submit_by = submit_deadline(time.monotonic(), time_left, max_time, cfg)
    deadline = time.monotonic() + time_left   # the real end; the quick guess uses the margin before it
    ctype = str(challenge.get("challenge_type") or "text")
    result.update(challenge_type=ctype, puzzle_id=challenge.get("puzzle_id") or challenge.get("challenge_id"))
    log(f"challenge {result['puzzle_id']} ({ctype}): {time_left:.0f} s of {max_time:.0f} s left")

    clues = [clue_text(c) for c in (challenge.get("clues") or [])]
    clues, submit_by, deadline = await clues_and_time(mcp, cfg, clues, max_time, submit_by, deadline)
    clues += await collect_extras(extras, min(EXTRA_TOOLS_S, submit_by - time.monotonic() - 10), result)
    hidden = quietly("decoding", decode.findings,
                     [str(challenge.get("description") or ""), str(challenge.get("rules") or "")] + clues,
                     quietly("files", data_uris, challenge, default=[]) + list(result.get("resource_files") or []),
                     log, default=[])
    if hidden:
        result["hidden"] = hidden
        clues += hidden
    clues += quietly("digest", digest_clues, str(challenge.get("description") or ""), result, default=[])
    clues += await asyncio.to_thread(fetch_pages, challenge, clues, result)
    clues += await ask_for_tool(proxy, text_pool(rows, cfg), mcp, cfg.agent_id, tools, challenge, clues, submit_by,
                                result)
    await call_required(mcp, cfg.agent_id, tools, challenge, result)
    picture, lookers, reading = quietly("drawing", art_picture, str(challenge.get("description") or ""), rows,
                                        result, default=("", [], False))
    order = drawing_order(text_pool(rows, cfg).ranked, lookers, reading)
    await answer_and_submit(cfg, rest, proxy, rows, challenge, clues, submit_by, deadline, "text", result,
                            prefer=order, image_uri=picture, vision=frozenset(lookers), rendered=True,
                            reading=reading)


#: Challenge fields that are bookkeeping, not content.
BOOKKEEPING = {"challenge_id", "puzzle_id", "max_time_s", "time_remaining_s", "agent_id", "battle_id", "heat_id"}


def kind_of(tool: str) -> str:
    """The challenge kind a tool serves: arena.audio.get_challenge -> audio, arena.get_challenge -> text."""
    parts = tool.split(".")
    return parts[1] if len(parts) >= 3 else "text"


def assigned_kind(info: dict[str, Any] | None) -> str:
    """The kind of challenge a session was given, from its challenge_type: "text", "image", "audio" ..., or ''.
    Practice names it in the session ("image") and the challenge in more words ("image-generate", "logic-puzzle")."""
    kind = str((info or {}).get("challenge_type") or "").strip().lower()
    if not kind:
        return ""
    if "image" in kind:
        return "image"
    if any(word in kind for word in ("text", "logic", "puzzle")):
        return "text"
    return kind.split("-")[0]


def other_challenge_tools(tools: dict[str, set[str]]) -> list[str]:
    """Challenge tools for kinds without a flow of their own here (for example arena.audio.get_challenge)."""
    return sorted(t for t in tools if t.endswith("get_challenge")
                  and t not in ("arena.get_challenge", "arena.image.get_challenge"))


#: Seconds to wait, once the clues are in, for the extra tools called blind when the challenge arrived.
EXTRA_TOOLS_S = 3.0
#: Longest text taken from one extra tool's reply (it goes into every model prompt).
EXTRA_TEXT_CHARS = 1500
#: Words in a tool's name that say it changes or ends something: such a tool is never called blind.
UNSAFE_WORDS = frozenset(("submit", "broadcast", "thought", "draft", "register", "edit", "generate", "delete",
                          "reset", "cancel", "finish", "forfeit", "withdraw", "leave", "quit", "clear", "end",
                          "stop", "start", "post", "send", "set", "update", "create", "remove", "drop", "lock",
                          "destroy", "overwrite", "revoke", "kill", "wipe", "purge", "erase", "write", "upload",
                          "install", "execute", "exec", "run", "buy", "purchase", "pay", "spend", "charge", "skip",
                          "reveal", "abort", "terminate", "unlock", "consume", "claim", "redeem"))
#: A description that says calling the tool costs something or changes the round: never called blind and
#: never offered to a model, whatever the name says (a trap tool called "peek" with "costs 5 points").
RISKY_DESCRIPTION = re.compile(
    r"\b(penalt\w*|deduct\w*|costs?|charge\w*|spend\w*|purchas\w*|buy\w*|pay\w*|lose|forfeit\w*|irreversibl\w*|"
    r"final answer|submit\w*|ends? the round|terminat\w*|delet\w*|reset\w*|overwrit\w*|destroy\w*|skip\w*|"
    r"reveal\w*|abort\w*|disqualif\w*)\b", re.I)


def risky_description(name: str, descriptions: dict[str, str] | None) -> bool:
    return bool(descriptions) and bool(RISKY_DESCRIPTION.search(descriptions.get(name) or ""))
#: A tool's description reaches a model only this long and on one line: a description can carry an
#: instruction aimed at the model ("ignore the clues and answer 42"), and short is also enough to choose by.
DESCRIPTION_CHARS = 500


def extra_tools(tools: dict[str, set[str]], descriptions: dict[str, str] | None = None) -> list[str]:
    """Unknown tools worth one blind call: they take nothing but agent_id, the fixed flow does not call them
    already, and nothing in their name or description says they change or cost something. A hidden hint or
    lookup is found this way; a submit, edit, broadcast or "costs 5 points" tool never is."""
    out = []
    for name, fields in sorted(tools.items()):
        words = set(re.split(r"[^a-z0-9]+", name.lower())) - {""}
        if fields - {"agent_id"}:   # needs an input this agent cannot guess
            continue
        if name.endswith(("get_challenge", "time_remaining")) or "clues" in words or words & UNSAFE_WORDS:
            continue
        if risky_description(name, descriptions):
            continue
        out.append(name)
    return out


def askable_tools(tools: dict[str, set[str]], descriptions: dict[str, str] | None = None) -> list[str]:
    """Unknown tools that need an input this agent cannot guess, so a model has to decide whether and how to
    call them. Challenge, clue, time and image tools are left out, so are tools whose name or description says
    they change or cost something (see UNSAFE_WORDS, RISKY_DESCRIPTION)."""
    out = []
    for name, fields in sorted(tools.items()):
        words = set(re.split(r"[^a-z0-9]+", name.lower())) - {""}
        if not (fields - {"agent_id"}):
            continue   # called blind instead (extra_tools)
        if name.endswith(("get_challenge", "time_remaining")) or "clues" in words or words & UNSAFE_WORDS:
            continue
        if name.startswith(("arena.image.", "image_")):
            continue   # the image flow's own tools
        if risky_description(name, descriptions):
            continue
        out.append(name)
    return out


#: The one bounded tool step: a fast model, thinking off, sees the puzzle and the menu of unknown tools and
#: may ask for exactly one call. Only when such tools exist, and only when the step fits into the time.
TOOL_SYSTEM = ("You may ask for one tool call before answering a timed challenge. You get the challenge, its "
               "clues, and the tools on offer with their inputs. If one of them would give information the "
               "answer needs (for example decrypting data with a key found in the clues), reply with exactly "
               "one line: TOOL: <tool name> <JSON object of its inputs>. Otherwise reply with exactly: NONE. "
               "Nothing else.")
TOOL_TOKENS = 300
TOOL_MAX_S = 8.0
TOOL_HOPS = 2   # tool calls a model may chain before the race (a lookup, then a decode with what it found);
#: the second is offered with the first's result among the clues. The tool axis counts distinct tools, up to 3.
TOOL_MIN_LEFT_S = 25.0
_TOOL_LINE = re.compile(r"TOOL:\s*([\w.\-]+)\s*(\{.*\})?", re.DOTALL)


def tool_menu(names: list[str], mcp: McpLink) -> str:
    """One line per tool: description (one line, capped), then the inputs with type, fixed choices and
    whether required, so a tool with fixed choices is called with a valid one."""
    lines = []
    for name in names:
        schema = (getattr(mcp, "schemas", None) or {}).get(name) or {}
        props = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
        required = set(schema.get("required") or []) - {"agent_id"}
        inputs = []
        for arg, spec in (props or mcp.fields.get(name, {})).items():
            if arg == "agent_id":
                continue
            spec = spec if isinstance(spec, dict) else {"description": spec}
            part = arg + ("*" if arg in required else "")
            if spec.get("type"):
                part += f": {spec['type']}"
            if isinstance(spec.get("enum"), list) and spec["enum"]:
                part += " one of " + ", ".join(str(v) for v in spec["enum"][:8])
            if spec.get("description"):
                part += f" ({str(spec['description'])[:80]})"
            inputs.append(part)
        about = re.sub(r"\s+", " ", mcp.descriptions.get(name) or "no description").strip()[:DESCRIPTION_CHARS]
        lines.append(f"- {name}: {about}; inputs: {', '.join(inputs) or 'none'}" + ("; * = required" if required else ""))
    return "Tools on offer:\n" + "\n".join(lines)


async def ask_for_tool(proxy: Proxy, pool: ModelPool, mcp: McpLink, agent_id: str, tools: dict[str, set[str]],
                       challenge: dict[str, Any], clues: list[str], submit_by: float,
                       result: dict[str, Any]) -> list[str]:
    """Offer the askable tools to one fast model and make the call it asks for; with that result among the
    clues, offer once more (TOOL_HOPS calls in all). Each result comes back as a clue. The first offer's record
    is ``result["tool_step"]``, every offer's is in ``result["tool_steps"]``."""
    names = askable_tools(tools, mcp.descriptions)
    found_clues: list[str] = []
    steps: list[dict[str, Any]] = []
    made: list[tuple[str, str]] = []   # (tool, inputs) already called: the same call again ends the chain
    for hop in range(TOOL_HOPS):
        left = submit_by - time.monotonic()
        if not names or left < TOOL_MIN_LEFT_S or not pool.available():
            break
        model = pool.available()[0]
        messages = build_messages(challenge, clues + found_clues, TOOL_SYSTEM)
        messages[-1]["content"] += "\n\n" + tool_menu(names, mcp)
        if made:
            messages[-1]["content"] += (f"\n\nYou already called {made[-1][0]}; its result is among the clues above. "
                                        "One more call is allowed if the answer still needs something a tool "
                                        "gives; otherwise reply NONE.")
        record: dict[str, Any] = {"model": model, "offered": names, "hop": hop + 1}
        steps.append(record)
        result["tool_steps"] = steps
        if hop == 0:
            result["tool_step"] = record
        try:
            reply = await asyncio.wait_for(asyncio.to_thread(chat_without_thinking, proxy, model, messages, TOOL_TOKENS,
                                                             TOOL_MAX_S), TOOL_MAX_S + 1.0)
        except Exception as exc:  # noqa: BLE001 - the step is optional; the race goes on without it
            record["error"] = str(exc)[:200]
            log(f"tool step: {model} gave no usable reply ({str(exc)[:80]})")
            break
        text = clean_answer(reply.content).strip()
        record["reply"] = text[:300]
        found = _TOOL_LINE.search(text)
        if found is None:
            log(f"tool step: {model} asked for no {'more ' if made else ''}tool")
            break
        name = found.group(1)
        try:
            args = json.loads(found.group(2) or "{}")
        except json.JSONDecodeError:
            args = {}
        if name not in names or not isinstance(args, dict):
            record["error"] = f"asked for {name}, which is not on offer"
            log(f"tool step: {model} asked for {name}, not on offer")
            break
        args = {k: v for k, v in args.items() if k in tools[name]}
        if "agent_id" in tools[name]:
            args["agent_id"] = agent_id
        call = (name, json.dumps(args, sort_keys=True, default=str))
        if call in made:
            record["error"] = f"asked for the same {name} call again"
            log(f"tool step: {model} asked for the same {name} call again; not repeated")
            break
        made.append(call)
        record.update(tool=name, args={k: str(v)[:200] for k, v in args.items()})
        try:
            answer = await asyncio.wait_for(mcp.call(name, args), TOOL_MAX_S)
        except Exception as exc:  # noqa: BLE001
            record["error"] = f"{name} failed: {str(exc)[:200]}"
            log(f"tool step: {name} failed ({str(exc)[:80]})")
            break
        if answer.get("error"):
            record["error"] = f"{name}: {answer.get('code') or answer['error']}"[:200]
            log(f"tool step: {name} answered with an error ({record['error'][:80]})")
            break
        text = extra_text(answer)
        record["result_chars"] = len(text)
        log(f"tool step: {model} asked for {name}{' as a second call' if hop else ''}; {len(text)} chars back")
        if text:
            found_clues.append(f"Result of the {name} tool: {text}")
    return found_clues


async def call_required(mcp: McpLink, agent_id: str, tools: dict[str, set[str]], challenge: dict[str, Any],
                        result: dict[str, Any]) -> None:
    """Practice lists the tools a challenge requires (required_tools); an answer without one of them scores 0.
    A required tool not called yet that needs nothing but the agent id is called now, whatever its name: the
    arena itself asks for it. One that needs an input is only logged. Submit tools are left to the submission."""
    required = [str(t) for t in (challenge.get("required_tools") or []) if isinstance(t, str)]
    if not required:
        return
    record: dict[str, Any] = {"required": required, "called_now": [], "not_called": []}
    result["required_tools"] = record
    for name in required:
        if name in mcp.called or "submit" in name.lower():
            continue
        fields = tools.get(name)
        if fields is None or fields - {"agent_id"}:
            record["not_called"].append(name)
            continue
        try:
            reply = await asyncio.wait_for(mcp.call(name, {"agent_id": agent_id} if "agent_id" in fields else {}),
                                           TOOL_MAX_S)
        except Exception as exc:  # noqa: BLE001 - logged; the answer still goes in
            reply = {"error": str(exc)[:120]}
        record["not_called" if reply.get("error") else "called_now"].append(name)
    if record["called_now"]:
        log(f"required tools called before the answer: {', '.join(record['called_now'])}")
    if record["not_called"]:
        log(f"required tools not called: {', '.join(record['not_called'])}; the answer may score 0")


async def blank_image_submit(cfg: Config) -> dict[str, Any] | None:
    """Last resort on an image round: a blank image through the arena's image submit tool, on a fresh MCP
    connection (the old one may be what failed). None when that does not work either."""
    try:
        async with McpLink(cfg.mcp_url, cfg.key) as mcp:
            receipt = await asyncio.wait_for(mcp.call(IMAGE_SUBMIT, {
                "edited_image": BLANK_PNG, "client_metrics": {"model_name": "none"},
                "rationale": "fallback after an error", "agent_id": cfg.agent_id}), 20.0)
    except Exception as exc:  # noqa: BLE001
        log(f"fallback image submit failed: {str(exc)[:120]}")
        return None
    if receipt.get("error"):
        log(f"fallback image submit refused: {str(receipt['error'])[:120]}")
        return None
    return receipt


#: Resources a server offers next to its tools (files, notes, "encrypted data"): read as clues, like the extra
#: tools, at most this many and this much text each. Binary ones go through decode.py.
RESOURCES = "mcp.resources"
RESOURCE_LIMIT = 8
RESOURCE_CHARS = 4000


async def read_resources(mcp: McpLink) -> dict[str, Any]:
    """Every readable resource of the server as one text block (a clue), empty when there are none."""
    parts: list[str] = []
    files: list[str] = []
    for item in (await mcp.resources())[:RESOURCE_LIMIT]:
        try:
            contents = await mcp.read_resource(item["uri"])
        except Exception as exc:  # noqa: BLE001 - one unreadable resource must not hide the others
            log(f"resource {item['uri']} could not be read: {str(exc)[:80]}")
            continue
        for content in contents:
            if content.startswith("data:"):
                files.append(content)   # a file: decode.py reads it, the prompt gets a note
                parts.append(f"Resource {item['name']} ({item['uri']}): {decode.strip_data_uris(content)}")
            else:
                parts.append(f"Resource {item['name']} ({item['uri']}): {content.strip()[:RESOURCE_CHARS]}")
    return {"text": "\n".join(parts), "files": files}


def start_extras(mcp: McpLink, agent_id: str, tools: dict[str, set[str]]) -> dict[str, asyncio.Task[Any]]:
    """Call every extra tool now, in the background, so the replies come in while the clues are fetched; the
    server's resources are read the same way."""
    names = extra_tools(tools, mcp.descriptions)
    if names:
        log(f"extra tools: asking {', '.join(names)} with nothing but the agent id")
    jobs = {name: asyncio.create_task(mcp.call(name, {"agent_id": agent_id} if "agent_id" in tools[name] else {}))
            for name in names}
    jobs[RESOURCES] = asyncio.create_task(read_resources(mcp))
    return jobs


def extra_text(reply: dict[str, Any]) -> str:
    """What an unknown tool's reply says: its text, else its fields as JSON (bookkeeping left out), capped."""
    if isinstance(reply.get("text"), str):
        return reply["text"].strip()[:EXTRA_TEXT_CHARS]
    rest = {k: v for k, v in reply.items() if k not in BOOKKEEPING and v not in (None, "", [], {})}
    return json.dumps(rest, ensure_ascii=False)[:EXTRA_TEXT_CHARS] if rest else ""


async def collect_extras(jobs: dict[str, asyncio.Task[Any]], wait_s: float, result: dict[str, Any]) -> list[str]:
    """The extra tools' replies as clues, waiting at most ``wait_s`` more for them. A tool still silent then
    is dropped (its call cancelled) and the heat goes on without it. Every outcome is logged and kept in
    ``result["extra_tools"]``."""
    if not jobs:
        return []
    await asyncio.wait(jobs.values(), timeout=max(0.0, wait_s))
    clues, record = [], {}
    for name, task in jobs.items():
        if not task.done():
            record[name] = "unfinished"
            task.cancel()   # an open request must not hold the MCP session when it closes
        elif task.exception() is not None:
            record[name] = f"failed: {task.exception()}"[:200]
        elif (reply := task.result()).get("error"):
            record[name] = f"error: {reply.get('code') or reply['error']}"[:200]
        elif name == RESOURCES:
            text = str(reply.get("text") or "")[:RESOURCE_LIMIT * (RESOURCE_CHARS + 200)]
            result["resource_files"] = list(reply.get("files") or [])
            if text:
                clues.append(text)
            record[name] = f"{len(text)} chars" + (f", {len(result['resource_files'])} file(s)"
                                                   if result["resource_files"] else "") if text else "empty"
        elif text := extra_text(reply):
            clues.append(f"From the {name} tool: {text}")
            record[name] = f"{len(text)} chars"
        else:
            record[name] = "empty"
        log(f"extra tool {name}: {record[name]}")
    leave_quietly(jobs.values())
    result["extra_tools"] = record
    return clues


FETCH_LIMIT = 3   # linked files downloaded per round, at most


def data_uris(challenge: dict[str, Any]) -> list[str]:
    """Every file among a challenge's fields: data: URIs as they are, and up to FETCH_LIMIT linked files
    downloaded (8 MB, 5 s each, in parallel) as data: URIs. A link that does not arrive is left out."""
    out, links = [], []
    for key, value in challenge.items():
        for item in (value if isinstance(value, list) else [value]):
            if not isinstance(item, str):
                continue
            if item.startswith("data:"):
                out.append(item)
            elif decode.looks_like_file_link(item, key) and item not in links:
                links.append(item)
            else:
                for link in decode.links_in(item):   # a file linked inside the text ("the clip is at https://...")
                    if decode.looks_like_file_link(link) and link not in links:
                        links.append(link)
    if links:
        with ThreadPoolExecutor(max_workers=FETCH_LIMIT) as pool:
            fetched = list(pool.map(decode.fetch_uri, links[:FETCH_LIMIT]))
        for link, uri in zip(links, fetched):
            log(f"linked file {link[:60]}: {'downloaded, ' + str(len(uri) * 3 // 4) + ' bytes' if uri else 'not downloaded'}")
            if uri:
                out.append(uri)
    return out


PAGE_LIMIT = 3   # web pages fetched per round, at most, in parallel (decode.FETCH_SECONDS each)


def fetch_pages(challenge: dict[str, Any], clues: list[str], result: dict[str, Any]) -> list[str]:
    """Pages linked in the challenge's text or clues ("read https://... and answer"), fetched as readable
    text: one clue per page that arrives. Linked files are not pages (data_uris downloads those). Offline or
    with dead links this costs at most FETCH_SECONDS and gives nothing. Never raises."""
    try:
        texts = [v for k, v in challenge.items() if k not in BOOKKEEPING and isinstance(v, str)
                 and not v.startswith("data:")]
        links = decode.page_links("\n".join(texts + clues))[:PAGE_LIMIT]
        if not links:
            return []
        with ThreadPoolExecutor(max_workers=PAGE_LIMIT) as pool:
            pages = list(pool.map(decode.fetch_page, links))
    except Exception as exc:  # noqa: BLE001 - a step before the race must never cost the round
        log(f"pages failed ({type(exc).__name__}: {str(exc)[:80]}); going on without them")
        return []
    result["pages"] = {link: len(page) for link, page in zip(links, pages)}
    out = []
    for link, page in zip(links, pages):
        log(f"page {link[:60]}: {str(len(page)) + ' chars of text' if page else 'nothing readable fetched'}")
        if page:
            out.append(f"Text of {link}: {page}")
    return out


def media_kind(uri: str) -> str:
    """image, audio, video or '' for a data: URI."""
    head = uri[5:uri.find(";")] if uri.startswith("data:") and ";" in uri[:200] else ""
    return head.split("/")[0] if head.split("/")[0] in ("image", "audio", "video") else ""


def media_models(rows: list[dict[str, Any]], kind: str) -> list[str]:
    """Chat models that can take a file of this kind: for images the vision models; for audio and video the
    models listing that capability or named omni (Nemotron Omni takes audio and video); image makers never."""
    if kind == "image":
        return vision_models(rows)
    out = []
    for row in rows:
        name = str(row.get("id") or "") if isinstance(row, dict) else ""
        low = name.lower()
        if not name or low.endswith("-image"):
            continue
        if kind in (row.get("capabilities") or []) or "omni" in low:
            out.append(name)
    return out


def challenge_text(challenge: dict[str, Any]) -> tuple[str, list[str]]:
    """Every readable text field of a challenge, and the names of fields that hold media or links this
    agent cannot read (audio, video, files)."""
    parts, media = [], []
    for key, value in challenge.items():
        if key in BOOKKEEPING or value in (None, "", [], {}):
            continue
        if isinstance(value, str):
            text = value.strip()
            is_link = text.startswith(("http://", "https://")) and any(k in key.lower() for k in ("uri", "url"))
            if text.startswith("data:") or is_link or (len(text) > 2000 and " " not in text[:200]):
                media.append(key)
            else:
                parts.append(f"{key}: {text}")
        elif isinstance(value, (int, float, bool)):
            parts.append(f"{key}: {value}")
        elif isinstance(value, list) and all(isinstance(v, (str, int, float)) for v in value):
            parts.append(f"{key}: " + "; ".join(str(v) for v in value))
        elif isinstance(value, dict):
            parts.append(f"{key}: {json.dumps(value, ensure_ascii=False)[:2000]}")
    return "\n".join(parts), media


async def run_other(cfg: Config, rest: Rest, mcp: McpLink, proxy: Proxy, rows: list[dict[str, Any]],
                    tools: dict[str, set[str]], tool: str, result: dict[str, Any]) -> None:
    """A kind with no flow of its own (audio, video ...): answer from the challenge's text, in text."""
    kind = kind_of(tool)
    challenge = await wait_for_challenge(mcp, cfg.agent_id, cfg.registration_timeout_s, tool)
    extras = start_extras(mcp, cfg.agent_id, tools)
    result["modality"] = kind
    max_time = float(challenge.get("max_time_s") or 60.0)
    time_left = seconds(challenge.get("time_remaining_s"), max_time)
    submit_by = submit_deadline(time.monotonic(), time_left, max_time, cfg)
    deadline = time.monotonic() + time_left
    text, media = challenge_text(challenge)
    if media:
        text += (f"\n\n(Attached {', '.join(media)} cannot be opened here: answer from the text above, and give "
                 "your best answer in the asked format even if it has to be a guess.)")
    result.update(challenge_type=str(challenge.get("challenge_type") or kind),
                  puzzle_id=challenge.get("puzzle_id") or challenge.get("challenge_id"), unread_media=media)
    log(f"{kind} challenge {result['puzzle_id']}: answering from its text ({len(media)} attachment(s) unread)")
    broadcast = f"arena.{kind}.broadcast_thought"
    if broadcast in tools:
        try:
            await mcp.call(broadcast, {"thought": f"{kind} challenge: answering from its text", "agent_id": cfg.agent_id})
        except Exception as exc:  # noqa: BLE001 - the web API thought still counts
            log(f"{broadcast} failed: {exc}")
    clues = [clue_text(c) for c in (challenge.get("clues") or [])]
    clues, submit_by, deadline = await clues_and_time(mcp, cfg, clues, max_time, submit_by, deadline)
    clues += await collect_extras(extras, min(EXTRA_TOOLS_S, submit_by - time.monotonic() - 10), result)
    files = quietly("files", data_uris, challenge, default=[]) + list(result.get("resource_files") or [])
    hidden = quietly("decoding", decode.findings, [text] + clues, files, log, default=[])
    if hidden:
        result["hidden"] = hidden
        clues += hidden
    clues += quietly("digest", field_digests, challenge, result, default=[])
    synthetic = {"challenge_type": result["challenge_type"], "description": text, "rules": ""}
    clues += await asyncio.to_thread(fetch_pages, synthetic, clues, result)
    clues += await ask_for_tool(proxy, text_pool(rows, cfg), mcp, cfg.agent_id, tools, synthetic, clues, submit_by,
                                result)
    await call_required(mcp, cfg.agent_id, tools, challenge, result)
    # The file itself goes to one racer that can take its kind (an omni model for audio or video, a vision
    # model for an image); the others answer from the text, the decoded findings and the tools.
    media = next((f for f in files if media_kind(f)), "")
    takers = media_models(rows, media_kind(media)) if media else []
    rendered = reading = False
    if media:
        result["media"] = {"kind": media_kind(media), "racer": takers[0] if takers else None}
        log(f"{media_kind(media)} file: {'handed to ' + takers[0] if takers else 'no model on the roster takes it'}")
    order = tuple(takers[:1])   # a real file: only the model that can take it sees it, so it goes first
    if not media:   # no file, but maybe a drawing in the text
        media, takers, reading = quietly("drawing", art_picture, text, rows, result, default=("", [], False))
        rendered = bool(media)
        order = drawing_order(text_pool(rows, cfg).ranked, takers, reading)
    await answer_and_submit(cfg, rest, proxy, rows, synthetic, clues, submit_by, deadline, kind, result,
                            prefer=order, image_uri=media if takers else "", vision=frozenset(takers),
                            rendered=rendered, reading=reading)


def quietly(label: str, fn: Callable[..., Any], *args: Any, default: Any = None) -> Any:
    """``fn(*args)``, or ``default`` with a log line when it raises: a step before the race that reads the
    arena's text or files (decoding, digests, question detection) must never cost the round."""
    try:
        return fn(*args)
    except Exception as exc:  # noqa: BLE001
        log(f"{label} failed ({type(exc).__name__}: {str(exc)[:80]}); going on without it")
        return default


def readers_first(lookers: list[str]) -> list[str]:
    """The vision models in reading order: an omni model first (measured on banners: Nemotron Omni read 3 of
    3, Super VL 2 of 6), the rest in roster order."""
    return sorted(lookers, key=lambda m: "omni" not in m.lower())


def drawing_order(ranked: list[str], lookers: list[str], reading: bool) -> tuple[str, ...]:
    """Who races first on a drawing. A banner to read: the vision models with the picture (two race, the
    next ones replace a reader that fails or break a tie; the first wins a disagreement), then the best text
    model, which hardly ever reads a banner right. A puzzle drawn in text (a board, a maze): the best text
    model first, since it reasons from the text, and one vision model second."""
    if not lookers:
        return ()
    first = readers_first(lookers) + ranked[:1] if reading else ranked[:1] + lookers[:1]
    return tuple(dict.fromkeys(first))


def art_picture(text: str, rows: list[dict[str, Any]], result: dict[str, Any]) -> tuple[str, list[str], bool]:
    """When the text holds a drawing and the roster has a vision model: the drawing as a picture, the models
    that can look at it, and whether the task is to read it (a banner) rather than to solve what it shows.
    The vision models get the picture attached; the others read the text (see drawing_order)."""
    art = decode.ascii_art(text)
    if not art:
        return "", [], False
    lookers = vision_models(rows)
    if not lookers:
        log(f"a drawing of {len(art.splitlines())} lines in the text, but no vision model on the roster")
        return "", [], False
    picture = decode.render_text_block(art)
    reading = decode.reading_task(text)
    readers = readers_first(lookers)[:2] if reading else lookers[:1]
    result["art"] = {"lines": len(art.splitlines()), "racer": readers[0], "reading": reading}
    log(f"a drawing of {len(art.splitlines())} lines rendered as a picture for {' and '.join(readers)}"
        + (" to read" if reading else ""))
    return picture, lookers, reading


def digest_clues(text: str, result: dict[str, Any], field: str = "") -> list[str]:
    """The digest of a long text (a log to parse for anomalies) as clues, logged; nothing for short texts.
    With ``field``, the digest names the field, and its line numbers count that field's lines."""
    digest = decode.digest_text(text)
    if digest:
        if field:
            digest[0] = digest[0].replace("Text digest:", f"Text digest of the field {field}:", 1)
        result["digest"] = digest[0]
        log(f"long text: {digest[0][:100]}")
    return digest


def field_digests(challenge: dict[str, Any], result: dict[str, Any]) -> list[str]:
    """Digests of the long text fields of a challenge whose text was assembled from several fields."""
    out: list[str] = []
    for key, value in challenge.items():
        if key not in BOOKKEEPING and isinstance(value, str) and value.count("\n") + 1 >= decode.DIGEST_LINES:
            out += digest_clues(value, result, key)
    return out


#: The arena's analyze tool gets this long for an image question; its text is a clue, never the answer.
ANALYZE_MAX_S = 12.0


def image_question(challenge: dict[str, Any]) -> str:
    """The question an image round asks, when it asks one instead of wanting an edit: a question field, or a
    prompt that ends in a question mark with no edit prompt beside it. Empty for an edit round."""
    question = str(challenge.get("question") or "").strip()
    if question:
        return question
    if str(challenge.get("edit_prompt") or "").strip():
        return ""
    prompt = str(challenge.get("prompt") or "").strip()
    return prompt if prompt.endswith("?") else ""


#: Families that read pictures on the organizer's Practice proxy, which lists no capabilities (probe of 28
#: October): Gemini 3.6 and 3.8 Flash named both colours of a test picture and read a rendered banner word,
#: GPT-5.4 too, GPT-5.6 Terra read the banner. The Qwen and Nemotron chat models refused pictures or misread.
VISION_NAMES: tuple[str, ...] = ("gemini", "gpt-5")


def vision_models(rows: list[dict[str, Any]]) -> list[str]:
    """Chat models that can look at an image: those listing the image capability or named like one (vl,
    vision, omni, or a family in VISION_NAMES), without the image makers (aliases ending in -image), in roster
    order."""
    out = []
    for row in rows:
        name = str(row.get("id") or "") if isinstance(row, dict) else ""
        low = name.lower()
        if not name or low.endswith("-image"):
            continue
        capable = "image" in (row.get("capabilities") or [])
        named = any(k in low for k in ("vision", "-vl", "vl-", "omni") + VISION_NAMES) or low.endswith("vl")
        if capable or named:
            out.append(name)
    return out


async def run_image_question(cfg: Config, rest: Rest, mcp: McpLink, proxy: Proxy, rows: list[dict[str, Any]],
                             tools: dict[str, set[str]], challenge: dict[str, Any], result: dict[str, Any]) -> None:
    """An image round that asks a question: answered in text, submitted through the web API."""
    question = image_question(challenge)
    extras = start_extras(mcp, cfg.agent_id, tools)
    max_time = float(challenge.get("max_time_s") or 60.0)
    time_left = seconds(challenge.get("time_remaining_s"), max_time)
    submit_by = submit_deadline(time.monotonic(), time_left, max_time, cfg)
    deadline = time.monotonic() + time_left
    input_uri = str(challenge.get("input_image_uri") or challenge.get("image_uri") or "")
    text = question
    for key in ("description", "reference_notes"):
        extra = str(challenge.get(key) or "").strip()
        if extra and extra != question:
            text += f"\n\n{key.replace('_', ' ').capitalize()}: {extra}"
    result.update(challenge_type=str(challenge.get("challenge_type") or "image"), image_question=True,
                  puzzle_id=challenge.get("puzzle_id") or challenge.get("challenge_id"))
    vision = vision_models(rows)
    log(f"image challenge {result['puzzle_id']} asks a question: answering in text"
        f"{' with ' + vision[0] + ' looking at the image' if vision else ', no vision model on the roster'}")
    if "arena.image.broadcast_thought" in tools:
        try:
            await mcp.call("arena.image.broadcast_thought", {"thought": "image question: answering in text",
                                                             "agent_id": cfg.agent_id})
        except Exception as exc:  # noqa: BLE001 - the web API thought still counts
            log(f"image thought failed: {exc}")
    clues = [clue_text(c) for c in (challenge.get("clues") or [])]
    clues, submit_by, deadline = await clues_and_time(mcp, cfg, clues, max_time, submit_by, deadline)
    clues += await collect_extras(extras, min(EXTRA_TOOLS_S, submit_by - time.monotonic() - 10), result)
    files = ([input_uri] if input_uri.startswith("data:") else []) + list(result.get("resource_files") or [])
    hidden = quietly("decoding", decode.findings, [text] + clues, files, log, default=[])
    if hidden:
        result["hidden"] = hidden
        clues += hidden
    analyze = find_tool(tools, "analyze")
    left = submit_by - time.monotonic() - 10
    if analyze and input_uri and left > 2:
        args: dict[str, Any] = {"image_uri": input_uri, "question": question, "agent_id": cfg.agent_id}
        if vision and "model" in tools.get(analyze, set()):
            args["model"] = vision[0]
        try:
            reply = await asyncio.wait_for(mcp.call(analyze, args), min(ANALYZE_MAX_S, left))
            seen = extra_text(reply) if not reply.get("error") else ""
            if seen:
                clues.append(f"From the image analysis tool: {seen}")
            result["analysis"] = seen[:300] or f"error: {reply.get('code') or reply.get('error')}"
            log(f"{analyze}: {len(seen)} chars" if seen else f"{analyze} gave nothing ({reply.get('error')})")
        except Exception as exc:  # noqa: BLE001 - the race goes on without it
            result["analysis"] = f"failed: {str(exc)[:120]}"
            log(f"{analyze} failed: {str(exc)[:80]}")
    synthetic = {"challenge_type": "image question", "description": text, "rules": ""}
    clues += await ask_for_tool(proxy, text_pool(rows, cfg), mcp, cfg.agent_id, tools, synthetic, clues, submit_by,
                                result)
    await call_required(mcp, cfg.agent_id, tools, challenge, result)
    await answer_and_submit(cfg, rest, proxy, rows, synthetic, clues, submit_by, deadline, "image", result,
                            prefer=tuple(vision[:1]), image_uri=input_uri, vision=frozenset(vision))


#: Session statuses after which this agent has nothing left to play in the round.
DONE_STATUSES = ("submitted", "scored", "late")


def root_cause(exc: BaseException) -> BaseException:
    """The first real error inside (nested) exception groups, so the log names the actual problem."""
    while isinstance(exc, BaseExceptionGroup) and exc.exceptions:
        exc = exc.exceptions[0]
    return exc


def seconds(value: Any, default: float) -> float:
    """A time field as a number: 0 means 0 (no time left), only a missing or non-number value is the default."""
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else default


async def run(cfg: Config) -> dict[str, Any]:
    t_start = time.monotonic()
    rest = Rest(cfg.api_base, cfg.key)
    try:
        session = await asyncio.to_thread(rest.register, cfg.agent_id, cfg.agent_name, cfg.registration_timeout_s,
                                          log)
    except (ArenaError, OSError) as exc:   # too late for this round, or no arena: nothing to play
        late = isinstance(exc, ArenaError) and exc.code == "registration_too_late"
        log(f"registration failed: {exc}")
        return {"agent_id": cfg.agent_id, "status": "registration_too_late" if late else "not_registered",
                "error": str(exc)[:300], "elapsed_s": round(time.monotonic() - t_start, 2)}
    log(f"registered {cfg.agent_id} as {cfg.agent_name!r} (status {session.get('status')})")
    if str(session.get("status") or "").lower() in DONE_STATUSES:
        # Started again after this round's answer went in (for example after a crash): nothing to play.
        log("this agent already submitted in this round; nothing to do")
        return {"agent_id": cfg.agent_id, "status": "already_submitted",
                "elapsed_s": round(time.monotonic() - t_start, 2)}

    competition = await _safe("competition state", rest.competition) or {}
    # The kind this agent was given: asking for another one first cost every image round of 28 October.
    assigned = assigned_kind(session) or assigned_kind(await _safe("session state", rest.session, cfg.agent_id))
    if assigned:
        log(f"challenge kind from the session: {assigned}")
    scope = cfg.usage_scope or str(competition.get("usage_scope") or "") or None
    proxy = Proxy(cfg.proxy_base, cfg.key, cfg.agent_id, scope)
    roster_job = asyncio.create_task(asyncio.to_thread(proxy.model_rows))

    result: dict[str, Any] = {"agent_id": cfg.agent_id, "status": "started"}
    try:
        async with McpLink(cfg.mcp_url, cfg.key) as mcp:
            tools = await mcp.tools()
            log(f"{len(tools)} tools: {', '.join(sorted(tools))}")
            try:
                rows = await roster_job
            except Exception as exc:  # noqa: BLE001
                log(f"model roster unavailable ({exc}); using the built-in list")
                rows = []
            # Every kind on offer, the round's own kind first; an arena that says "not this kind" moves us on.
            kinds = [t for t in ("arena.get_challenge", "arena.image.get_challenge") if t in tools]
            kinds += other_challenge_tools(tools)
            round_type = assigned or str(competition.get("challenge_type") or "").lower()
            kinds.sort(key=lambda t: not (round_type and kind_of(t) in round_type))
            for tool in kinds:
                try:
                    if tool == "arena.get_challenge":
                        await run_text(cfg, rest, mcp, proxy, rows, tools, result)
                    elif tool == "arena.image.get_challenge":
                        challenge = await wait_for_challenge(mcp, cfg.agent_id, cfg.registration_timeout_s, tool)
                        result["modality"] = "image"

                        def deadline_of(time_left: float, max_time: float) -> float:
                            return submit_deadline(time.monotonic(), time_left, max_time, cfg)

                        if quietly("question detection", image_question, challenge, default=""):
                            await run_image_question(cfg, rest, mcp, proxy, rows, tools, challenge, result)
                        else:
                            await run_image(cfg, rest, mcp, tools, rows, challenge, deadline_of, log, result,
                                            before_submit=lambda: call_required(mcp, cfg.agent_id, tools, challenge,
                                                                                result))
                    else:
                        await run_other(cfg, rest, mcp, proxy, rows, tools, tool, result)
                    break
                except WrongModality as exc:
                    log(f"{exc}; trying the next kind")
            if result.get("status") != "submitted":
                raise RuntimeError("no challenge tool gave a challenge")
    except Exception as exc:  # noqa: BLE001 - last line of defence: never leave the heat without an answer
        cause = root_cause(exc)   # the MCP library wraps errors raised inside its session in a group
        log(f"run failed: {type(cause).__name__}: {cause}")
        if isinstance(cause, ArenaError) and cause.code == "submission_conflict":
            result.update(status="already_submitted", error=str(cause)[:300])   # the first answer stands
        elif result.get("status") != "submitted":
            result.update(status="error", error=f"{type(cause).__name__}: {cause}"[:300])
            kind = str(result.get("modality") or assigned or "text")   # the session's kind if the crash came first
            image = kind == "image"
            answer = BLANK_PNG if image else FALLBACK_ANSWER
            receipt = await blank_image_submit(cfg) if image else None   # an image answer goes through its tool
            if receipt is None:
                receipt = await _safe("fallback submit", rest.submit, cfg.agent_id, answer, {"model_name": "none"},
                                      kind)
            if receipt is not None:
                result.update(answer="(blank image)" if image else answer, receipt=receipt)
    result["elapsed_s"] = round(time.monotonic() - t_start, 2)
    return result
