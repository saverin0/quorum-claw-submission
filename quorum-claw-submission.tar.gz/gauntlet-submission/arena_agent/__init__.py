"""Lean arena agent: plays one Agent Gauntlet heat through the arena's web API, MCP tools and model proxy."""
