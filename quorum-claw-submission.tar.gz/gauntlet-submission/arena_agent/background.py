"""Calls still running when the agent moves on (a racer that lost, a second guess, a slow image tool).

They may fail later. Unless someone collects that failure, Python prints "Task exception was never
retrieved" with a traceback when the task is cleaned up, which looks like a crash in the middle of a heat.
leave_quietly() collects each such result or failure as soon as it arrives and drops it.
"""
from __future__ import annotations

import asyncio
from typing import Any, Iterable


def _collect(task: asyncio.Future[Any]) -> None:
    if not task.cancelled():
        task.exception()   # marks the failure as seen; the result itself is no longer needed


def leave_quietly(tasks: Iterable[asyncio.Future[Any]]) -> None:
    for task in tasks:
        task.add_done_callback(_collect)
