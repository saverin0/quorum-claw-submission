"""Settings for the arena agent, read from the environment.

The organizer injects ARENA_SERVER and ARENA_API_KEY (and in scored heats ARENA_USAGE_SCOPE); the only file
read is the hand-in's own label, for the display name, so the same code runs locally, against the practice
arena and in the organizer's sandbox.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse

LOOPBACK = {"localhost", "127.0.0.1", "::1"}
DEFAULT_AGENT_ID = "claw-agent"
#: The hand-in's own label, written by package_submission.py next to agent_entry.py. Its display name is used
#: when AGENT_NAME is not set, so the agent registers under the name it was submitted with: the event rules say
#: a second registration with the same id and a different name is rejected. The source tree has no such file.
SUBMISSION_FILE = Path(__file__).resolve().parent.parent / "submission.json"


@dataclass(frozen=True)
class Config:
    api_base: str              # origin for the web API; paths start with /api
    mcp_url: str               # MCP over SSE
    proxy_base: str            # OpenAI-compatible model proxy; paths /models and /chat/completions
    key: str
    agent_id: str
    agent_name: str
    usage_scope: str | None    # X-Round-ID for the proxy; read from /api/competition when not injected
    submit_fraction: float = 0.8       # submit by this share of the time limit
    min_margin_s: float = 4.0          # but never closer than this to the deadline
    #: Racers' token limit. 8192 rather than 4096: on hard puzzles fast models ran out of room at 10 to 20 s;
    #: with 8192 DeepSeek finished two futoshiki puzzles itself at about 16 s, while easy puzzles stay as fast
    #: (they end long before either limit). ARENA_MAX_TOKENS overrides it.
    max_tokens: int = 8192
    #: How long to wait for the lobby to open and then for GO. Generous on purpose: an agent that gives up in
    #: a long lobby never plays; ARENA_LOBBY_WAIT_S overrides it.
    registration_timeout_s: float = 7200.0
    model_cooldown_s: float = 60.0     # how long a failed model is skipped


def resolve_urls(server: str) -> tuple[str, str, str]:
    """Origin, MCP URL and proxy base from ARENA_SERVER. Remote hosts must use HTTPS; a bare host is
    HTTPS unless it is loopback. Everything is a path on one origin, as on the event and practice servers."""
    raw = server.strip().rstrip("/")
    if not raw:
        raise ValueError("ARENA_SERVER is empty")
    if "://" not in raw:
        host = raw.split("/")[0].rsplit(":", 1)[0].strip("[]").lower()
        raw = ("http://" if host in LOOPBACK else "https://") + raw
    parsed = urlparse(raw)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in ("http", "https") or not host:
        raise ValueError(f"cannot use ARENA_SERVER {server!r}")
    if parsed.scheme == "http" and host not in LOOPBACK:
        raise ValueError("remote arena URLs must use https")
    origin = f"{parsed.scheme}://{parsed.netloc}"
    return origin, origin + "/sse", origin + "/proxy"


def submitted_name(path: Path | None = None) -> str:
    """metadata.agentName from the hand-in's submission.json, or "" when there is none."""
    try:
        data = json.loads((path or SUBMISSION_FILE).read_text(encoding="utf-8"))
        return str(data["metadata"]["agentName"]).strip()
    except (OSError, ValueError, KeyError, TypeError):
        return ""


def from_env(env: Mapping[str, str] = os.environ) -> Config:
    server = (env.get("ARENA_SERVER") or "").strip()
    key = (env.get("ARENA_API_KEY") or "").strip()
    if not server or not key:
        raise SystemExit("ARENA_SERVER and ARENA_API_KEY must be set")
    api, mcp, proxy = resolve_urls(server)
    api = (env.get("ARENA_API_BASE") or "").strip().rstrip("/") or api
    mcp = (env.get("ARENA_MCP_URL") or "").strip() or mcp
    proxy = (env.get("LLM_PROXY_HOST") or "").strip().rstrip("/") or proxy
    agent_id = (env.get("AGENT_ID") or "").strip() or DEFAULT_AGENT_ID
    agent_name = (env.get("AGENT_NAME") or "").strip() or submitted_name() or agent_id
    scope = (env.get("ARENA_USAGE_SCOPE") or "").strip() or None
    extra: dict[str, Any] = {}
    wait = (env.get("ARENA_LOBBY_WAIT_S") or "").strip()
    if wait:
        extra["registration_timeout_s"] = float(wait)
    tokens = (env.get("ARENA_MAX_TOKENS") or "").strip()   # token limit of the racers, for tuning runs
    if tokens:
        extra["max_tokens"] = int(tokens)
    return Config(api, mcp, proxy, key, agent_id, agent_name, scope, **extra)
