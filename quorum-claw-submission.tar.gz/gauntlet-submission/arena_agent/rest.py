"""Web API client for the arena: register, competition state, thought, draft, submit.

Requests carry the arena key in X-Arena-API-Key. Errors come back as {"detail": {"code": ...}}; the code
decides what to do (lobby_not_open: wait and retry; registration_too_late: stop).
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Any, Callable

#: How long registration keeps trying an arena it cannot reach (a minute covers an arena still starting or a
#: wifi hiccup, and still ends soon with a clear error for a wrong address).
NETWORK_RETRY_S = 60.0

class ArenaError(Exception):
    def __init__(self, status: int, code: str | None, message: str) -> None:
        super().__init__(f"HTTP {status} {code or ''}: {message}".strip())
        self.status = status
        self.code = code
        self.message = message


class Rest:
    def __init__(self, base: str, key: str, timeout: float = 20.0) -> None:
        self.base = base.rstrip("/")
        self.key = key
        self.timeout = timeout

    def _request(self, method: str, path: str, body: dict[str, Any] | None = None,
                 timeout: float | None = None) -> dict[str, Any]:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = urllib.request.Request(self.base + path, data=data, method=method, headers={
            "Content-Type": "application/json", "Accept": "application/json", "X-Arena-API-Key": self.key})
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            text = exc.read().decode("utf-8", "replace")
            code = None
            try:
                payload = json.loads(text)
                detail = payload.get("detail") if isinstance(payload, dict) else None
                if isinstance(detail, dict) and isinstance(detail.get("code"), str):
                    code = detail["code"]
            except json.JSONDecodeError:
                pass
            raise ArenaError(exc.code, code, text[:300]) from None
        if not raw:
            return {}
        parsed = json.loads(raw.decode("utf-8"))
        return parsed if isinstance(parsed, dict) else {"data": parsed}

    def register(self, agent_id: str, agent_name: str, timeout_s: float,
                 log: Callable[[str], None] = print) -> dict[str, Any]:
        """Register for the round. While the lobby is closed (409) wait with backoff; a late registration
        (409 registration_too_late) is final for this round and is raised. An arena that cannot be reached
        or answers with a server error (still starting, a wifi hiccup) is tried again for NETWORK_RETRY_S;
        after that the error is raised, so a wrong address does not keep the agent waiting."""
        deadline = time.monotonic() + timeout_s
        network_deadline = time.monotonic() + NETWORK_RETRY_S
        delay = 1.0
        while True:
            try:
                return self._request("POST", "/api/session/register", {"agent_id": agent_id, "agent_name": agent_name})
            except ArenaError as exc:
                if exc.status >= 500 and time.monotonic() < network_deadline:
                    log(f"arena error {exc.status}; retrying in {delay:.0f} s")
                elif exc.status != 409 or exc.code == "registration_too_late" or time.monotonic() >= deadline:
                    raise
                else:
                    log(f"lobby not open yet ({exc.code}); retrying in {delay:.0f} s")
            except OSError as exc:
                if time.monotonic() >= network_deadline:
                    raise
                log(f"arena not reachable yet ({exc}); retrying in {delay:.0f} s")
            time.sleep(delay)
            delay = min(delay * 2.0, 10.0)

    def competition(self) -> dict[str, Any]:
        return self._request("GET", "/api/competition")

    def session(self, agent_id: str) -> dict[str, Any]:
        """This agent's session: status, score and, on Practice, the kind of challenge it was given."""
        return self._request("GET", f"/api/session/{agent_id}")

    def thought(self, agent_id: str, text: str) -> bool:
        return bool(self._request("POST", "/api/thought", {"agent_id": agent_id, "thought": text}).get("accepted"))

    def draft(self, agent_id: str, draft: str, rationale: str | None = None) -> bool:
        body: dict[str, Any] = {"agent_id": agent_id, "draft": draft}
        if rationale:
            body["rationale"] = rationale
        return bool(self._request("POST", "/api/draft", body).get("saved"))

    def submit(self, agent_id: str, answer: str, client_metrics: dict[str, Any],
               challenge_type: str | None = "text") -> dict[str, Any]:
        """Final answer. The first one is official; if the response is lost, the exact same answer is sent
        once more, which returns the original receipt."""
        payload: dict[str, Any] = {"agent_id": agent_id, "answer": answer, "client_metrics": client_metrics}
        if challenge_type is not None:
            payload["challenge_type"] = challenge_type
        try:
            return self._request("POST", "/api/submit", payload, timeout=30)
        except ArenaError:
            raise
        except OSError:  # connection dropped or timed out: the answer may have been recorded
            return self._request("POST", "/api/submit", payload, timeout=30)
