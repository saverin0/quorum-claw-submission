"""Model access through the arena's proxy: roster, ranking, failover and answer cleaning.

Every call carries Authorization: Bearer <key>, X-Agent-ID and (when known) X-Round-ID, so the arena can
credit the tokens to this agent. A model that fails (overloaded, error, timeout or empty answer) is
skipped for a cooldown and the next ranked model takes over; no model call decides this.
"""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable

#: Preference patterns, best first. Model table (each model once on the 80 practice puzzles, on Nebius):
#: GLM-5.3-Flash 56 right at a median 6.6 s, DeepSeek-V4.1-Flash 55 at 5.0 s, Super 53, Nano 50, gpt-oss-20b
#: 53 (but 7 missing answers on NVIDIA's free tier); Kimi (46) and Ultra (45) were less accurate and cost
#: more, so they follow in the roster's own order. In the races DeepSeek answered easy puzzles in about 1 s
#: and Super in 2 to 4 s, while GLM never answered within the 5 s patience, so GLM races third.
#: On the organizer's Practice proxy (OpenRouter, 28 October), 10 logic puzzles each, one per type: GPT-5.6 Terra
#: 10 of 10 at a median 4.4 s, Gemini 3.6 Flash 10 at 6.4 s, Gemini 3.8 Flash 10 at 7.3 s, Qwen 3.7 Max 9 at
#: 8.1 s, Nemotron Ultra 8 at 6.2 s, Super 8 at 12.2 s (two timeouts), Qwen 3.7 Plus 9 but 18.5 s. GPT-5.4
#: answers in under 2.4 s but 7 of 10: racing first, its sure answers would go in before a check, so it is
#: left to the roster's order, and so is Ultra (45 of 80 on the older NVIDIA table below). The older table
#: follows for rosters without these models.
PREFERENCE: tuple[str, ...] = ("gpt-5.6-terra", "gemini-3.6-flash", "gemini-3.8-flash", "qwen3.7-max",
                               "deepseek-v4.1-flash", "nemotron-3-super", "nemotron-super", "glm-5.3-flash",
                               "qwen3.7-plus", "nemotron-3-nano", "nemotron-nano-3", "gpt-oss")
#: Patterns ranked last: Lightning (38 of 80, slow) and the small vision model (19 of 80) on text.
DEMOTE: tuple[str, ...] = ("lightning", "vision")
#: Who writes the program: in the program trial Super with thinking off wrote working programs in about 2 s;
#: the others were not tried with thinking off. Without a match the best ranked model writes it.
CODE_PREFERENCE: tuple[str, ...] = ("nemotron-3-super", "nemotron-super")
FALLBACK_ROSTER: tuple[str, ...] = ("nemotron-3-super", "nemotron-3-ultra")


class ModelError(Exception):
    def __init__(self, model: str, kind: str, detail: str = "", reply: str = "", reasoning: str = "") -> None:
        super().__init__(f"{model}: {kind} {detail}".strip())
        self.model = model
        self.kind = kind
        self.reply = reply            # what the model sent, when it sent something unusable (for the run log)
        self.reasoning = reasoning


@dataclass
class ChatResult:
    model: str
    content: str
    usage: dict[str, Any]
    ms: float
    finish_reason: str | None
    reasoning: str = ""   # thinking sent in a separate field (reasoning_content) instead of <think> in content
    program: str = ""     # for the program racer: the program whose output is ``content``
    reads: str = ""       # what that program says it read: "text", "layout", or "" when it does not say


def rank_models(model_ids: list[str], preference: tuple[str, ...] = PREFERENCE,
                demote: tuple[str, ...] = DEMOTE) -> list[str]:
    """Text models in the order to try: preferred patterns first, then the roster's own order, demoted last.
    Image-generation aliases (ending in -image) are left out for text challenges."""
    pool = [m for m in model_ids if not m.lower().endswith("-image")]

    def demoted(m: str) -> bool:
        return any(d in m.lower() for d in demote)

    ranked: list[str] = []
    for pattern in preference:
        for m in pool:
            if pattern in m.lower() and m not in ranked and not demoted(m):
                ranked.append(m)
    rest = [m for m in pool if m not in ranked]
    ranked += [m for m in rest if not demoted(m)]
    ranked += [m for m in rest if demoted(m)]
    return ranked


def pick_first(models: list[str], preference: tuple[str, ...]) -> str | None:
    """The first model matching the best preference pattern, else the first model, else None."""
    for pattern in preference:
        for m in models:
            if pattern in m.lower():
                return m
    return models[0] if models else None


@dataclass
class ModelPool:
    """Ranked models with a simple circuit breaker."""
    ranked: list[str]
    cooldown_s: float = 60.0
    clock: Callable[[], float] = time.monotonic
    down_until: dict[str, float] = field(default_factory=dict)

    def available(self) -> list[str]:
        now = self.clock()
        return [m for m in self.ranked if self.down_until.get(m, 0.0) <= now]

    def mark_down(self, model: str) -> None:
        self.down_until[model] = self.clock() + self.cooldown_s


_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.S | re.I)
_THINK_OPEN = re.compile(r"<think>.*\Z", re.S | re.I)
_PREFIX = re.compile(r"^(?:final\s+)?answer\s*[:\-]\s*", re.I)
_FENCE = re.compile(r"^```[^\n]*\n(.*?)\n?```$", re.S)


_SPACES = re.compile(r"\s+")


def normalize(answer: str) -> str:
    """Form used only to compare answers from different models: case, spacing and surrounding
    punctuation do not count."""
    return _SPACES.sub(" ", answer.strip().lower()).strip(" .!;:'\"`")


_CONFIDENCE = re.compile(r"^[ \t*_]*confidence[ \t*_]*[:=][ \t*_]*(\d{1,3})[ \t]*%?[ \t*_]*$", re.I | re.M)


def split_confidence(answer: str) -> tuple[str, int | None]:
    """The answer without its last 'Confidence: N' line, and N (0 to 100) when the model gave one."""
    matches = list(_CONFIDENCE.finditer(answer))
    if not matches:
        return answer, None
    last = matches[-1]
    return (answer[:last.start()] + answer[last.end():]).strip(), max(0, min(100, int(last.group(1))))


def clean_answer(text: str | None) -> str:
    """The final answer from a model reply: thinking removed (also an unclosed block from a cut-off reply),
    a leading 'Answer:' dropped, a surrounding code fence removed. Inner lines are kept (grids, lists)."""
    t = _THINK_BLOCK.sub("", text or "")
    t = _THINK_OPEN.sub("", t).strip()
    fenced = _FENCE.match(t)
    if fenced:
        t = fenced.group(1).strip()
    t = _PREFIX.sub("", t, count=1).strip()
    return t


class Proxy:
    def __init__(self, base: str, key: str, agent_id: str, usage_scope: str | None) -> None:
        self.base = base.rstrip("/")
        self.key = key
        self.agent_id = agent_id
        self.usage_scope = usage_scope

    def headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json", "Accept": "application/json",
             "Authorization": f"Bearer {self.key}", "X-Agent-ID": self.agent_id}
        if self.usage_scope:
            h["X-Round-ID"] = self.usage_scope
        return h

    def model_rows(self, timeout: float = 15.0) -> list[dict[str, Any]]:
        """The proxy's roster as rows (id, and capabilities when the proxy lists them)."""
        request = urllib.request.Request(self.base + "/models", headers=self.headers(), method="GET")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
        rows = data.get("data", []) if isinstance(data, dict) else data
        return [r for r in rows if isinstance(r, dict) and r.get("id")]

    def models(self, timeout: float = 15.0) -> list[str]:
        return [str(r["id"]) for r in self.model_rows(timeout)]

    def chat(self, model: str, messages: list[dict[str, Any]], max_tokens: int, timeout: float,
             extra: dict[str, Any] | None = None) -> ChatResult:
        """One chat call; ``extra`` adds fields to the request body (for example a thinking switch)."""
        body = {"model": model, "messages": messages, "max_tokens": max_tokens, "temperature": 0, **(extra or {})}
        request = urllib.request.Request(self.base + "/chat/completions", data=json.dumps(body).encode("utf-8"),
                                         headers=self.headers(), method="POST")
        t0 = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=max(1.0, timeout)) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise ModelError(model, f"http_{exc.code}", exc.read().decode("utf-8", "replace")[:200]) from None
        except (urllib.error.URLError, OSError) as exc:
            raise ModelError(model, "unreachable_or_timeout", str(exc)[:200]) from None
        ms = (time.perf_counter() - t0) * 1000.0
        choice = (data.get("choices") or [{}])[0] if isinstance(data, dict) else {}
        message = choice.get("message") or {}
        content = str(message.get("content") or "")
        reasoning = str(message.get("reasoning_content") or message.get("reasoning") or "")
        if choice.get("finish_reason") == "length":
            # Cut off at the token limit: some models send their thinking as plain text, which would
            # otherwise pass for an answer. The text is kept, so the quick guess can build on it.
            raise ModelError(model, "cut_off", "finish_reason=length", reply=content, reasoning=reasoning)
        if not clean_answer(content):
            raise ModelError(model, "empty_answer", f"finish_reason={choice.get('finish_reason')}",
                             reply=content, reasoning=reasoning)
        return ChatResult(model, content, data.get("usage") or {}, ms, choice.get("finish_reason"), reasoning)
